package cn.ruisiyuan.javaweb.listener;

import java.io.Serializable;

import javax.servlet.http.HttpSessionActivationListener;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;
import javax.servlet.http.HttpSessionEvent;

/**
 * HttpSessionBindingListener, HttpSessionActivationListener
 * 该监听器不需要在web.xml文件中进行配置.(很少使用)
 * @author Xiefang
 *
 */
public class Customer implements HttpSessionBindingListener, 
				HttpSessionActivationListener, Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String time;

	public void setTime(String time) {
		this.time = time;
	}

	/**
	 * 当前对象被绑定到session中时, 调用该方法.
	 */
	@Override
	public void valueBound(HttpSessionBindingEvent event) {
		System.out.println("绑定到session...");
		
		Object value = event.getValue();
		System.out.println(value == this); //true
		System.out.println(event.getName());

	}
	
	/**
	 * 当前对象从session中移除绑定时, 调用该方法.
	 */
	@Override
	public void valueUnbound(HttpSessionBindingEvent event) {
		System.out.println("从session中解除绑定...");
	}
	                                                                   
	/**
	 * 在钝化之前被调用.
	 * 钝化: 向磁盘中写入session对象
	 * session对象存储在 tomcat服务器的 work\Catalina\localhost\contextPath 目录下.                                                                                                                                                                                                                                                                                                                                                                                                                     
	 * SESSION.SER
	 */
	@Override
	public void sessionWillPassivate(HttpSessionEvent se) {
		System.out.println("从内存写入磁盘中...");
	}
	
	/**
	 * 在活化之后被调用.
	 * 活化: 从磁盘中读取session对象
	 */
	@Override
	public void sessionDidActivate(HttpSessionEvent se) {
		System.out.println("从磁盘读取到内存中...");
	}
	
	@Override
	public String toString() {
		return super.toString() + ", time: " + time;
	}

}
