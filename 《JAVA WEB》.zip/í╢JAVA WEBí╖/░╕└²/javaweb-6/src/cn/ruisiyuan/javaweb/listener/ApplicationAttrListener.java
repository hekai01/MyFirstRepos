package cn.ruisiyuan.javaweb.listener;

import javax.servlet.ServletContextAttributeEvent;
import javax.servlet.ServletContextAttributeListener;
import javax.servlet.ServletRequestAttributeEvent;
import javax.servlet.ServletRequestAttributeListener;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

/**
 * Servlet属性监听器: (较少使用)
 * <br>用于监听ServletContext,HttpSession,ServletRequest 三个域对象的属性的更改.
 * <br>添加属性: attributeAdded
 * <br>移除属性: attributeRemoved
 * <br>替换属性的值: attributeReplaced
 */
public class ApplicationAttrListener implements ServletContextAttributeListener, 
				HttpSessionAttributeListener, ServletRequestAttributeListener{
	
	/**
	 * 添加属性: ServletContext.setAttribute(), 调用该方法.
	 */
	@Override
	public void attributeAdded(ServletContextAttributeEvent scab) {
		System.out.println("向ServletContext中添加了一个属性: " + scab.getName()+" : "+scab.getValue());

	}
	
	/**
	 * 移除属性: ServletContext.removeAttribute(), 调用该方法.
	 */
	@Override
	public void attributeRemoved(ServletContextAttributeEvent scab) {
		System.out.println("向ServletContext中移除了一个属性: "+ scab.getName()+" : "+scab.getValue());

	}
	
	/**
	 * 更改已存在属性的属性值: ServletContext.setAttribute(), 调用该方法.
	 */
	@Override
	public void attributeReplaced(ServletContextAttributeEvent scab) {
		System.out.println("ServletContext中替换了一个属性: "+ scab.getName()+" : "+scab.getValue());
	}

	@Override
	public void attributeAdded(ServletRequestAttributeEvent srae) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attributeRemoved(ServletRequestAttributeEvent srae) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attributeReplaced(ServletRequestAttributeEvent srae) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attributeAdded(HttpSessionBindingEvent se) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attributeRemoved(HttpSessionBindingEvent se) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void attributeReplaced(HttpSessionBindingEvent se) {
		// TODO Auto-generated method stub
		
	}

}
