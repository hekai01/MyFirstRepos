package cn.ruisiyuan.javaweb.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 * ServletContextListener: (最常用)
 * <br>监听ServletContext对象被创建或销毁的Servlet监听器.
 * <br>1. 创建: contextInitialized, 在web应用被当前web容器加载时,
 *     web容器为当前web应用创建ServletContext对象,调用该方法.
 * <br>2. 销毁: attributeRemoved, 当前Web应用被卸载时,调用该方法.
 */
public class ApplicationListener implements ServletContextListener, 
			HttpSessionListener, ServletRequestListener {
	
	/**
	 * ServletContext 对象被创建时(当前web应用被加载时), Servlet容器调用该方法.
	 */
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		System.out.println("ServletContext 对象被创建了...");
		
		//可以在当前web应用被加载时对当前web应用的相关资源进行初始化操作.
		//1. 创建数据库连接池
		//2. 读取当前web应用的初始化参数
		//3. 创建Spring的IOC容器
		//...
		
		//sce.getServletContext()
		
	}
	
	/**
	 * ServletContext 对象被销毁之前(当前web应用被卸载时), Servlet容器调用该方法.
	 */
	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		System.out.println("ServletContext 对象被销毁了...");
	}
	
	/**
	 * HttpSession 对象被创建时, web容器调用该方法.
	 */
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		System.out.println("HttpSession 对象被创建了...");
		
	}
	
	/**
	 * HttpSession 对象被销毁时, web容器调用该方法.
	 */
	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		System.out.println("HttpSession 对象被销毁了...");
		
	}
	
	/**
	 * ServletRequest 对象被创建时, web容器调用该方法.
	 * request是一个请求, 当一个响应返回时即被销毁. 当发送一个请求时被创建.
	 * 1). 通过forward请求转发的过程中，始终是一个request对象.
	 * 2). redirect重定向是两个请求.
	 * 3). 超链接访问方式，是创建一个全新的request对象 .
	 */
	@Override
	public void requestInitialized(ServletRequestEvent sre) {
		System.out.println("ServletRequest 对象被创建了...");
		
	}
	
	/**
	 * ServletRequest 对象被销毁时, web容器调用该方法.
	 */
	@Override
	public void requestDestroyed(ServletRequestEvent sre) {
		System.out.println("ServletRequest 对象被销毁了...");
		
	}
}
