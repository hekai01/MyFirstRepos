package cn.ruisiyuan.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ForwardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		System.out.println("forward...");
		
		//请求转发与重定向
		//1. 本质区别: 请求转发只发出了一次请求，而重定向则发出了两次请求.
		//1.1). 请求转发: 地址栏是初次发出请求的地址
		//      请求重定向: 地址栏不再是初次发出请求的地址，地址栏为最后响应的地址.
		//1.2). 请求转发: 在最终的Servlet中，request对象和中转的那个request 是 同一个对象
		//      请求重定向: 在最终的Servlet中，request对象和中转的那个request 不是 同一个对象
		//1.3). 请求转发: 只能转发给当前web应用的资源
		//		请求重定向: 可以重定向到任何资源.
		//1.4). 请求转发: / 代表的是当前web应用的根目录
		//		请求重定向: / 代表的是当前web站点的根目录.
		
		request.setAttribute("name", "name-forward");
		
		//请求转发
		//1. 调用HttpServletRequest的getRequestDispatcher()方法获取RequestDispatcher对象
		//调用getRequestDispatcher() 需要传入要转发的地址
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/forward2.do");
		
		//2. 调用HttpServletRequest 的forward(request, response)进行请求的转发
		requestDispatcher.forward(request, response);
	}

}
