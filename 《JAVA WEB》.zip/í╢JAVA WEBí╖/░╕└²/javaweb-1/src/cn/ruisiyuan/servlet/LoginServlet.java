package cn.ruisiyuan.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginServlet implements Servlet{

	@Override
	public void destroy() {
	}

	@Override
	public ServletConfig getServletConfig() {
		return null;
	}

	@Override
	public String getServletInfo() {
		return null;
	}

	@Override
	public void init(ServletConfig arg0) throws ServletException {
	}
	
	/**
	 * ServletRequest: 封装了请求信息. 可以从中获取任何的请求信息.
	 * ServletResponse: 封装了响应信息.
	 * 这两个接口的实现类都是服务器给予实现的，并在服务器调用 service 方法时传入.
	 */
	@Override
	public void service(ServletRequest request, ServletResponse response)
			throws ServletException, IOException {
		System.out.println("我来了...");
		
		//request.getParameter(String name)
		//根据请求参数名，返回参数值
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		System.out.println(username+" : "+password);
		
		//request.getParameterValues(String name)
		//根据请求参数名，返回请求参数对应的字符串数组
		String[] interests = request.getParameterValues("interesting");
		for(String interest : interests){
			System.out.println("-->"+interest);
		}
		
		//返回参数名对应的Enumeration对象
		//类似于ServletConfig和ServletContext对象的getInitParamterNames()方法
		Enumeration<String> names =  request.getParameterNames();
		while(names.hasMoreElements()){
			String name = names.nextElement();
			String value = request.getParameter(name);
			System.out.println("^^^"+ name+" : "+value);
		}
		
		//返回请求参数的键值对：
		//key:参数名，value:参数值，String数组
		Map<String,String[]> map =  request.getParameterMap();
		for(Map.Entry<String, String[]> entry : map.entrySet()){
			System.out.println("***" +entry.getKey() + " : "+ Arrays.asList(entry.getValue()));
		}
		
		//HttpServletRequest接口
		//是ServletRequest的子接口，针对HTTP请求所定义，里面包含了大量获取HTTP请求相关的方法
		HttpServletRequest httpServletRequest = (HttpServletRequest)request;
		
		//获取请求URI
		String requestURI = httpServletRequest.getRequestURI();
		System.out.println(requestURI);
		
		//获取请求方式
		String method = httpServletRequest.getMethod();
		System.out.println(method);
		
		//若是GET请求方式：获取请求参数对应的字符串，即？后面的字符串
		//若是POST请求，则返回null
		String queryString = httpServletRequest.getQueryString();
		System.out.println(queryString);
		
		//获取请求servlet的映射路径
		String servletPath = httpServletRequest.getServletPath();
		System.out.println(servletPath);
		
		//...
		
		//设置响应的内容类型
		//response.setContentType("application/msword");
		
		//getWriter()返回PrintWriter对象，调用该对象的print()方法，
		//将把print()中的参数直接打印到客户的浏览器上显示
		PrintWriter out = response.getWriter();
		out.print("helloworld");
		
		//response.getOutputStream(): 文件下载
		
		//HttpServletResponse接口
		//是ServletResponse的子接口
		HttpServletResponse httpServletResponse = (HttpServletResponse)response;
		//httpServletResponse.sendRedirect(""): 重定向
	}

}
