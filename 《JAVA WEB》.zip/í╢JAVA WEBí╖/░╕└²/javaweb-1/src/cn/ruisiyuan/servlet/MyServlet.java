package cn.ruisiyuan.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * HttpServlet
 * 1. 是一个Servlet，继承自GenericServlet. 针对HTTP协议所定制.
 * 2. 在service()方法中直接把ServletRequest和ServletResponse
 *    转为HttpServletRequest和HttpServletResponse，
 *    并调用了重载的service(HttpServletRequest,HttpServletResponse)方法，
 *    获取了请求方式: getMethod()，根据请求方式又创建了doXXX()方法.
 * 3. 实际开发中，直接继承HttpServlet，并根据请求方式直接覆写doXXX()方法.
 */
public class MyServlet extends HttpServlet{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3994601288039863347L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//1. 获取请求的用户名和密码
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		//2. 获取系统初始化参数
		String initUser = getServletContext().getInitParameter("user");
		String initPassword = getServletContext().getInitParameter("password");
		
		//3. 比较、输出内容到客户端浏览器
		PrintWriter out = response.getWriter();
		if(initUser.equals(username) && initPassword.equals(password)){
			out.print("Hello: "+username);
		}else{
			out.print("Sorry: "+username);
		}
	}
}
