package cn.ruisiyuan.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class HelloServlet implements Servlet{
	
	/**
	 * servlet生命周期相关的方法：
	 * 1. 构造器
	 * 2. init方法
	 * 3. service方法
	 * 4. destroy方法
	 * 
	 * 只被调用一次，只有第一次请求servlet时，创建servlet的实例，调用构造器。
	 * 说明servlet是一个单实例的，线程不安全。
	 */
	public HelloServlet() {
		System.out.println("HelloServlet's constructor...");
	}
	
	/**
	 * 只被调用一次，在servlet创建好实例后立即被调用，
	 * 用于初始化当前的servlet。
	 */
	@Override
	public void init(ServletConfig servletConfig) throws ServletException {
		System.out.println("init()...");
		
		//获取初始化参数
		String user = servletConfig.getInitParameter("user");
		System.out.println("user: "+user);
		
		//获取初始化参数的名字
		Enumeration<String> names = servletConfig.getInitParameterNames();
		while(names.hasMoreElements()){
			String name = names.nextElement();
			System.out.println("name: "+name);
		}
		
		//获取servlet名字
		String servletName = servletConfig.getServletName();
		System.out.println("ServletName: "+servletName);
		
		//获取ServletContext对象
		//该对象代表当前web应用，可从中获取当前web应用的各个方面信息
		ServletContext sc = servletConfig.getServletContext();
		
		String user2 = sc.getInitParameter("user");
		System.out.println("user: "+user2);
		
		Enumeration<String> names2 =  sc.getInitParameterNames();
		while(names2.hasMoreElements()){
			String name = names2.nextElement();
			System.out.println("-->: "+name);
		}
		
		//获取当前web应用的某一个文件在服务器上的绝对路径，而不是部署前的路径
		String path = sc.getRealPath("adb.txt");
		System.out.println(path);
		
		//获取当前web应用名称
		String context = sc.getContextPath();
		System.out.println(context);
		
		//获取当前web应用的某一个文件对应的输入流
		//1.
		InputStream is = sc.getResourceAsStream("/WEB-INF/classes/adbc.txt");
		System.out.println("is-->"+is);
		
		//2.Class class
		InputStream is2 = getClass().getClassLoader().getResourceAsStream("adbc.txt");
		System.out.println("is2-->"+is2);
	}
	
	/**
	 * 被多次调用，每次请求都会调用service方法，实际用于响应请求的。
	 */
	@Override
	public void service(ServletRequest arg0, ServletResponse arg1)
			throws ServletException, IOException {
		System.out.println("service()...");
	}
	
	/**
	 * 只被调用一次，在当前servlet所在的web应用被卸载前调用，
	 * 用于释放当前servlet所占用的资源。
	 */
	@Override
	public void destroy() {
		System.out.println("destroy()...");
	}

	@Override
	public ServletConfig getServletConfig() {
		System.out.println("getServletConfig()...");
		return null;
	}

	@Override
	public String getServletInfo() {
		System.out.println("getServletInfo()...");
		return null;
	}

}
