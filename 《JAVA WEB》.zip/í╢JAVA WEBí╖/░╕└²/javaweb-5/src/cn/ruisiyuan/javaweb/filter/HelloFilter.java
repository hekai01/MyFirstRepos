package cn.ruisiyuan.javaweb.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * Filter
 * 1. Filter是什么?
 * 1.1). JavaWeb的一个重要组件,可以对发送到Servlet的请求进行拦截,并对响应也进行拦截.
 * 1.2). Filter 是实现了Filter接口的Java类.
 * 1.3). Filter 需要在web.xml文件中进行注册和映射.
 */
public class HelloFilter implements Filter {
	
	/**
	 * 1). 类似于 Servlet 的 init方法, 在创建Filter对象 (Filter对象在 Servlet容器 加载当前web应用时即被创建)后,
	 *     立即被调用,且只被调用一次. 该方法用于对当前的Filter进行初始化操作.
	 *     Filter 实例是单例的.
	 * <br>
	 * 2). FilterConfig 类似于 ServletConfig.
	 * <br>
	 * 3). 可以在web.xml文件中配置当前Filter的初始化参数. 配置方式也和Servlet类似.
	 * 
	 */
	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		System.out.println("init...");
		
	}
	
	/**
	 * 1). 真正Filter 的逻辑代码需要编写在该方法中. 每次拦截都会调用该方法.
	 * <br>
	 * 2). FilterChain: Filter链. 多个Filter可以构成一个Filter链.
	 * <br>    
	 * 3). doFilter方法把请求传给 Filter链 的下一个Filter. 若当前Filter 是Filter链 的最后一个Filter,
	 *     则把请求给到目标Servlet(或JSP).
	 * <br>
	 * 4). 多个Filter拦截的顺序和 <filter-mapping>配置的顺序有关, 靠前的先被调用.
	 */
	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		System.out.println("1. Before HelloFilter's chain.doFilter...");
		
		//放行
		chain.doFilter(request, response);
		
		System.out.println("5. After HelloFilter's chain.doFilter...");
	}
	
	/**
	 * 释放当前Filter所占用的资源的方法. 在Filter被销毁之前调用, 且只被调用一次.
	 */
	@Override
	public void destroy() {
		System.out.println("destroy...");

	}

}
