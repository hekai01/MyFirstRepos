package cn.ruisiyuan.javaweb.filter;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginFilter extends HttpFilter {
	
	private String userSessionKey;
	private String redirectUrl;
	private String uncheckedUrls;
	
	@Override
	protected void init() {
		
		//从web.xml中获取系统初始化信息: userSessionKey,redirectUrl,uncheckedUrls
		ServletContext servletContext = getFilterConfig().getServletContext();
		
		userSessionKey = servletContext.getInitParameter("userSessionKey");
		redirectUrl = servletContext.getInitParameter("redirectUrl");
		uncheckedUrls = servletContext.getInitParameter("uncheckedUrls");
	}

	@Override
	public void doFilter(HttpServletRequest request,
			HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		
		//1. 获取请求的 ServletPath
		// http://localhost:8080/javaweb-5/login/login.jsp
		// String url = request.getRequestURL().toString();
		// /javaweb-5/login/login.jsp
		// String uri = request.getRequestURI();
		// /login/login.jsp
		String servletPath = request.getServletPath();
		
		//2. 检查获取的servletPath是否为不需要检查的url中的一个,若是,直接放行.
		List<String> urls = Arrays.asList(uncheckedUrls.split(","));
		if(urls.contains(servletPath)){
			chain.doFilter(request, response);
			return ;
		}
		
		//3. 从 session 中获取 sessionKey对应的值, 若值不存在, 则重定向到redirectUrl.
		Object user = request.getSession().getAttribute(userSessionKey);
		if(user == null){
			response.sendRedirect(request.getContextPath() + redirectUrl);
			return ;
		}
		
		//4. 若存在, 允许访问，直接放行.
		chain.doFilter(request, response);
	}

}
