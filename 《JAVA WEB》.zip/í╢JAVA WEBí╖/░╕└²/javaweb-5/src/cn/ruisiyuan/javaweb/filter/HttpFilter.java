package cn.ruisiyuan.javaweb.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 自定义HttpFilter, 实现了 Filter 接口.
 * 
 * @author Xiefang
 *
 */
public abstract class HttpFilter implements Filter {
	
	/**
	 * 用于保存 FilterConfig 对象.
	 */
	private FilterConfig filterConfig;
	
	/**
	 * 不建议子类直接覆盖.
	 * 若直接覆盖, 将可能导致 filterConfig 成员变量初始化失败.
	 */
	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
		init();
	}
	
	/**
	 * 提供给子类继承的初始化方法. 
	 * 可以通过 getFilterConfig() 获取 FilterConfig对象.
	 */
	protected void init(){}
	
	/**
	 * 直接返回 init(FilterConfig filterConfig) 的 FilterConfig对象.
	 * @return FilterConfig
	 */
	public FilterConfig getFilterConfig() {
		return filterConfig;
	}
	
	/**
	 * 原生的 doFilter方法.
	 * <br>
	 * 在方法内部把 ServletRequest和 ServletResponse 转为了HttpServletRequest 和 HttpServletResponse,
	 * 并调用了doFilter(HttpServletRequest request,HttpServletResponse response,FilterChain chain).
	 * <br>
	 * 若编写Filter的doFilter方法,不建议直接继承该方法,而建议继承
	 * doFilter(HttpServletRequest request,HttpServletResponse response,FilterChain chain).
	 */
	public void doFilter(ServletRequest request, ServletResponse response, 
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpServletRequest = (HttpServletRequest)request;
		HttpServletResponse httpServletResponse = (HttpServletResponse)response;
		
		doFilter(httpServletRequest, httpServletResponse, chain);
		
	}


	/**
	 * 抽象方法,为HTTP请求定制. 必须实现的方法.
	 * @param chain FilterChain
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @throws IOException
	 * @throws ServletException
	 */
	public abstract void doFilter(HttpServletRequest request,
			HttpServletResponse response,
			FilterChain chain) throws IOException,
			ServletException;

	/**
	 * 空的 destroy() 方法.
	 */
	public void destroy() {}

}
