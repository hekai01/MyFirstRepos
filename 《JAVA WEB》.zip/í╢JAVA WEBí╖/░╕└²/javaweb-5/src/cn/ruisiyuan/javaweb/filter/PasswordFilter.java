package cn.ruisiyuan.javaweb.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class PasswordFilter implements Filter {
	
	private FilterConfig filterConfig;

	public void destroy() {
		
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, 
			FilterChain chain) throws IOException, ServletException {
		//1. 获取系统初始化参数 和 请求参数
		String initPassword = filterConfig.getServletContext().getInitParameter("password");
		//获取请求参数
		String password = request.getParameter("password");
		
		//2. 比较
		if(! initPassword.equals(password)){
			request.setAttribute("message", "密码错误.");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return ;
		}
		
		chain.doFilter(request, response);
	}

	public void init(FilterConfig fConfig) throws ServletException {
		this.filterConfig = fConfig;
	}

}
