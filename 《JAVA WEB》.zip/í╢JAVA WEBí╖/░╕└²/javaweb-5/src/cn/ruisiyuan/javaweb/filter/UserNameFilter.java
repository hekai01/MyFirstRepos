package cn.ruisiyuan.javaweb.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

public class UserNameFilter implements Filter {
	
	private FilterConfig filterConfig;

	public void destroy() {
		
	}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
			throws IOException, ServletException {
		//1.获取Filter初始化参数 
		String initUsername = filterConfig.getInitParameter("username");
		//获取请求参数
		String username = request.getParameter("username");
		
		//2. 比较
		if(! initUsername.equals(username)){
			request.setAttribute("message", "用户名错误.");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
			return ;
		}
		
		chain.doFilter(request, response);
	}

	public void init(FilterConfig fConfig) throws ServletException {
		this.filterConfig = fConfig;
	}

}
