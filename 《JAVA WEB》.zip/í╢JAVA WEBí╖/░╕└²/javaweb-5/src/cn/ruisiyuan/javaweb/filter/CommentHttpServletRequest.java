package cn.ruisiyuan.javaweb.filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

public class CommentHttpServletRequest extends HttpServletRequestWrapper {

	public CommentHttpServletRequest(HttpServletRequest request) {
		super(request);
		
	}
	
	@Override
	public String getParameter(String name) {
		String value = super.getParameter(name);
		if(value != null){
			if(value.contains("sb")){
				value = value.replace("sb", "**");
			}
		}
		return value;
	}

}
