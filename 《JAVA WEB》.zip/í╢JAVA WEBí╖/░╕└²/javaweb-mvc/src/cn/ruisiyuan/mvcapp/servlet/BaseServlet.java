package cn.ruisiyuan.mvcapp.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 自定义Servlet基类, 开发继承该类即可.
 * 条件: 约定优于配置
 */
public class BaseServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	private static final String REDIRECT_PATH = "redirect:";
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String methodName = request.getParameter("method");
		
		try {
			Method method = getClass().getDeclaredMethod(methodName, HttpServletRequest.class,
					HttpServletResponse.class);
			String path = (String)method.invoke(this, request, response);
			
			if(path.startsWith(REDIRECT_PATH)){
				response.sendRedirect(path.substring(REDIRECT_PATH.length()));
			}else{
				request.getRequestDispatcher(path).forward(request, response);
			}
		} catch (Exception e) {
			
		}
	}

}
