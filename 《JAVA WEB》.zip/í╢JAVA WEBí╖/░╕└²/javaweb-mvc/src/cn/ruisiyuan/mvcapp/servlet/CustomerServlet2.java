package cn.ruisiyuan.mvcapp.servlet;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.ruisiyuan.mvcapp.dao.CustomerDao;
import cn.ruisiyuan.mvcapp.dao.impl.CustomerDaoJdbcImpl;
import cn.ruisiyuan.mvcapp.domain.Customer;
import cn.ruisiyuan.mvcapp.query.CriteriaCustomer;

public class CustomerServlet2 extends BaseServlet {
	private static final long serialVersionUID = 1L;
	
	private CustomerDao dao = new CustomerDaoJdbcImpl();
	
	/**
	 * 查询客户
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	protected String query(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException{
		
		//1. 获取请求参数
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		
		//2. 将查询条件封装到 CriteriaCustomer 查询类中
		CriteriaCustomer criteria = new CriteriaCustomer(name, address, phone);
		
		//3. 调用 CustomerDao 的 queryForList 方法得到 Customer 集合
		List<Customer> customers = dao.queryForList(criteria);
		
		//4. 将Customer 集合放入到 request 请求域中
		request.setAttribute("customers", customers);
		
		//5. 转发到要展示的页面index.jsp(不能使用重定向)
		return "index.jsp";
	}
	
	/**
	 * 根据 ID 删除单个客户
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	protected String delete(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		//1. 获取请求参数 id
		String idStr = request.getParameter("id");
		
		int id = 0;
		
		//2. try ... catch 的作用: 防止 idStr 不能转为 int 类型
		//若不能转则 id = 0, 无法进行任何的删除操作.
		try {
			id = Integer.parseInt(idStr);
			
			//3. 调用 CustomerDao 的 delete 方法删除 该 ID 对应的记录
			dao.delete(id);
		} catch (NumberFormatException e) {}
		
		//4. 重定向到 查询客户方法进行显示.
		return "redirect:customerServlet?method=query";
	}
	
	/**
	 * 保存 或 修改 客户
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	protected String save(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		//1. 获取表单参数
		String idStr = request.getParameter("id");
		String oldName = request.getParameter("oldName");
		String name = request.getParameter("name");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		
		//2. 检验 name 是否已经被占用:
		//2.1). 比较oldName 和 name 是否相同, 若相同说明name可用.
		//		若不相同, 则调用 CustomerDao 的 getCount 方法查询 name 在数据库中是否存在.
		if(! oldName.equals(name)){
			long count = dao.getCount(name);
			//2.2). 返回值若大于0, 则响应到 edit.jsp 页面:
			if(count > 0){
				//2.2.1). 要求在 edit.jsp 页面显示一个提示消息: The name already in use.
				request.setAttribute("message", "CustomerName "+ name +" already in use.");
				
				//2.2.2). edit.jsp 的表单值可以回显.
				
				//转发到 edit.jsp 页面
//				request.getRequestDispatcher("/edit.jsp").forward(request, response);
				return "edit.jsp";
			}
		}

		//2. 把表单参数封装为一个 Customer 对象
		Customer customer = new Customer(name, address, phone);
		
		//3. 判断是新增客户 还是 修改客户. 若 id 为空, 则新增客户.
		if("".equals(idStr)){
			//3.1  调用 CustomerDao 的 save 方法执行保存操作
			dao.save(customer);
		} else {
			customer.setId(Integer.parseInt(idStr));
			//3.2 调用 CustomerDao 的 update 方法执行修改操作
			dao.update(customer);
		}
		
		//5. 重定向到 success.jsp 页面: 使用重定向可以避免出现表单重复提交问题.
		return "redirect:success.jsp";
	}
	
	/**
	 * 转发到 编辑客户页面: edit.jsp
	 * @param request
	 * @param response
	 * @throws ServletException
	 * @throws IOException
	 */
	protected String forwardEditPage(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		//出异常后跳转的页面
		String forwardPath = "/error.jsp";
		
		//1. 获取请求参数 id
		String idStr = request.getParameter("id");

		try {
			//2. 调用 CustomerDao 的 get 方法获取 id对应的 Customer 对象
			Customer customer = dao.get(Integer.parseInt(idStr));
			if(customer != null){
				forwardPath = "/edit.jsp";
				
				//3. 将获取的  Customer 对象放入到 request 请求域中
				request.setAttribute("customer", customer);
			}
		} catch (NumberFormatException e) {}
		
		//4. 响应到 edit.jsp 页面: 转发.
		return forwardPath;
	}
}
