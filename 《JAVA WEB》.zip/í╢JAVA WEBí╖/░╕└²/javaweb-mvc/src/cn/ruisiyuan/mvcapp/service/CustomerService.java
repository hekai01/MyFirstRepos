package cn.ruisiyuan.mvcapp.service;

import java.util.List;

import cn.ruisiyuan.mvcapp.domain.Customer;
import cn.ruisiyuan.mvcapp.query.CriteriaCustomer;

public interface CustomerService {	
		/**
		 * 保存客户
		 * @param customer
		 */
		public void saveCustomer(Customer customer);
		
		/**
		 * 修改客户
		 * @param customer
		 */
		public void updateCustomer(Customer customer);
		
		/**
		 * 查询所有记录, 不带查询条件
		 * @return List<>
		 */
		public List<Customer> queryCustomerForList();
		
		/**
		 * 查询客户, 带查询条件
		 * @param criteria
		 * @return List<>
		 */
		public List<Customer> queryCustomerForList(CriteriaCustomer criteria);
		
		/**
		 * 根据 id 查询
		 * @param id
		 * @return Customer
		 */
		public Customer getCustomer(int id);
		
		/**
		 * 根据 id 删除
		 * @param id
		 */
		public void deleteCustomer(int id);

}
