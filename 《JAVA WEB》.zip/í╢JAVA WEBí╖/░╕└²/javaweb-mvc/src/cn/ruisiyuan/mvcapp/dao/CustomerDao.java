package cn.ruisiyuan.mvcapp.dao;

import java.util.List;

import cn.ruisiyuan.mvcapp.domain.Customer;
import cn.ruisiyuan.mvcapp.query.CriteriaCustomer;

public interface CustomerDao {
	
	/**
	 * 保存客户
	 * @param customer
	 */
	public void save(Customer customer);
	
	/**
	 * 修改客户
	 * @param customer
	 */
	public void update(Customer customer);
	
	/**
	 * 查询所有记录, 不带查询条件
	 * @return List<>
	 */
	public List<Customer> queryForList();
	
	/**
	 * 查询客户, 带查询条件
	 * @param criteria
	 * @return List<>
	 */
	public List<Customer> queryForList(CriteriaCustomer criteria);
	
	/**
	 * 根据 id 查询
	 * @param id
	 * @return Customer
	 */
	public Customer get(int id);
	
	/**
	 * 根据 id 删除
	 * @param id
	 */
	public void delete(int id);
	
	/**
	 * 返回和 name 相等的记录数
	 * @param name
	 * @return 记录数
	 */
	public long getCount(String name);
}
