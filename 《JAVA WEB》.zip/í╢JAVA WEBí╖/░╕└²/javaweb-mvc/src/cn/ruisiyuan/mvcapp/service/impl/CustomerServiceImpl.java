package cn.ruisiyuan.mvcapp.service.impl;

import java.util.List;

import cn.ruisiyuan.mvcapp.dao.CustomerDao;
import cn.ruisiyuan.mvcapp.dao.impl.CustomerDaoJdbcImpl;
import cn.ruisiyuan.mvcapp.domain.Customer;
import cn.ruisiyuan.mvcapp.query.CriteriaCustomer;
import cn.ruisiyuan.mvcapp.service.CustomerService;

public class CustomerServiceImpl implements CustomerService {
	
	CustomerDao dao = new CustomerDaoJdbcImpl();

	@Override
	public void saveCustomer(Customer customer) {
		dao.save(customer);
	}

	@Override
	public void updateCustomer(Customer customer) {
		dao.update(customer);
	}

	@Override
	public List<Customer> queryCustomerForList() {
		return null;
	}

	@Override
	public List<Customer> queryCustomerForList(CriteriaCustomer criteria) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer getCustomer(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCustomer(int id) {
		// TODO Auto-generated method stub
		
	}

}
