package cn.ruisiyuan.mvcapp.test;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import cn.ruisiyuan.mvcapp.dao.CustomerDao;
import cn.ruisiyuan.mvcapp.dao.impl.CustomerDaoJdbcImpl;
import cn.ruisiyuan.mvcapp.domain.Customer;
import cn.ruisiyuan.mvcapp.query.CriteriaCustomer;

public class CustomerDaoJdbcImplTest {
	
	private CustomerDao dao = null;
	
	@Before
	public void config(){
		dao = new CustomerDaoJdbcImpl();
	}

	@Test
	public void testSave() {
		Customer customer = new Customer("Lucy", "UK", "2345678");
		dao.save(customer);
	}
	
	@Test
	public void testQuery(){
		List<Customer> customers = dao.queryForList();
		for(Customer customer : customers){
			System.out.println(customer);
		}
	}
	
	@Test
	public void testGet(){
		Customer customer = dao.get(1);
		System.out.println(customer);
	}
	
	@Test
	public void testDelete(){
		dao.delete(1);
	}
	
	@Test
	public void testGetCount(){
		long count = dao.getCount("Lucy");
		System.out.println(count);
	}
	
	@Test
	public void testCriteriaQuery(){
		CriteriaCustomer criteria = new CriteriaCustomer("c","U","3");
		List<Customer> customers = dao.queryForList(criteria);
		for(Customer customer : customers){
			System.out.println(customer);
		}
	}
}
