package cn.ruisiyuan.mvcapp.test;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.Test;

import cn.ruisiyuan.mvcapp.db.JdbcUtils;

public class JdbcUtilsTest {

	@Test
	public void testConnection() throws SQLException {
		Connection conn = JdbcUtils.getConnection();
		System.out.println(conn);
	}

}
