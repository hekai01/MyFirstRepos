package cn.ruisiyuan.mvcapp.dao.impl;

import java.util.List;

import cn.ruisiyuan.mvcapp.dao.CustomerDao;
import cn.ruisiyuan.mvcapp.domain.Customer;
import cn.ruisiyuan.mvcapp.query.CriteriaCustomer;

public class CustomerDaoJdbcImpl extends BaseDao<Customer> 
				implements CustomerDao {

	@Override
	public void save(Customer customer) {
		String sql = "INSERT INTO customer (name, address, phone) VALUES (?, ?, ?)";
		update(sql, customer.getName(), customer.getAddress(), customer.getPhone());
	}

	@Override
	public List<Customer> queryForList() {
		String sql = "SELECT id, name, address, phone FROM customer";
		return queryForList(sql);
	}

	@Override
	public Customer get(int id) {
		String sql = "SELECT id, name, address, phone FROM customer WHERE id = ?";
		return query(sql, id);
	}

	@Override
	public void delete(int id) {
		String sql = "DELETE FROM customer WHERE id = ?";
		update(sql, id);
	}

	@Override
	public long getCount(String name) {
		String sql = "SELECT COUNT(id) FROM customer WHERE name = ?";
		return getSingleVal(sql, name);
	}

	@Override
	public List<Customer> queryForList(CriteriaCustomer criteria) {
		String sql = "SELECT id, name, address, phone FROM customer "
				+ "WHERE name LIKE ? "
				+ "AND address LIKE ? "
				+ "AND phone LIKE ?";
		
		//修改了 CriteriaCustomer 的getter 方法: 使其返回的字符串中有 "%%".
		//若返回值为 null 则返回 "%%", 若不为 null 则返回 "%" + 字段本身的值 + "%"
		return queryForList(sql, criteria.getName(), 
				criteria.getAddress(), criteria.getPhone());
	}
	
	@Override
	public void update(Customer customer) {
		String sql = "UPDATE customer SET name = ?, address = ?, "
				+ "phone = ? WHERE id = ?";
		update(sql, customer.getName(), customer.getAddress(), 
				customer.getPhone(), customer.getId());
	}

}
