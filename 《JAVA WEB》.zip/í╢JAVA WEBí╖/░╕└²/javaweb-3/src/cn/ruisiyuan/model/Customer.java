package cn.ruisiyuan.model;

public class Customer{
	private String username; //顾客姓名
	private String address; //寄送地址
	private String cardType; //信用卡种类
	private String cardNo; //卡号
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCardType() {
		return cardType;
	}
	public void setCardType(String cardType) {
		this.cardType = cardType;
	}
	public String getCardNo() {
		return cardNo;
	}
	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	public Customer(String username, String address, String cardType,
			String cardNo) {
		super();
		this.username = username;
		this.address = address;
		this.cardType = cardType;
		this.cardNo = cardNo;
	}
	
	public Customer() {
		
	}
}
