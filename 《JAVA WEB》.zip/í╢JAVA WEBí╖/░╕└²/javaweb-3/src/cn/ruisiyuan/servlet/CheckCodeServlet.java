package cn.ruisiyuan.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CheckCodeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		//1.
		String paramCode = request.getParameter("CHECK_CODE_PARAM_NAME");
		
		//2.
		HttpSession session = request.getSession();
		String sessionCode = (String)session.getAttribute("CHECK_CODE_KEY");
		
		//3.
		if(!(paramCode != null && paramCode.equals(sessionCode))){
			session.setAttribute("message", "checkCode error!");
			response.sendRedirect(request.getContextPath()+"/checkCode/login.jsp");
			return;
		}
		
		request.getRequestDispatcher("/checkCode/success.jsp")
				.forward(request, response);
	}

}
