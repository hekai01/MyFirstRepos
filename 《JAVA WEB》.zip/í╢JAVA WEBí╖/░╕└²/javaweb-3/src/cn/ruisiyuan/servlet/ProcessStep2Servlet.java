package cn.ruisiyuan.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.ruisiyuan.model.Customer;

public class ProcessStep2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		//1. 获取请求参数: username,address,cardType,cardNo
		String username = request.getParameter("username");
		String address = request.getParameter("address");
		String cardType = request.getParameter("cardType");
		String cardNo = request.getParameter("cardNo");
		
		Customer customer = new Customer(username,address,cardType,cardNo);
		
		//2. 把请求信息存入到HttpSession中
		request.getSession().setAttribute("customer", customer);
		
		//3. 重定向到 shoppingCart/step3.jsp
		response.sendRedirect(request.getContextPath()+"/shoppingCart/step3.jsp");
	}

}
