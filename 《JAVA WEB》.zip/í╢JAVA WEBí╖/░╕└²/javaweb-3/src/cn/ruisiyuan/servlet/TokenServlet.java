package cn.ruisiyuan.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class TokenServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
//		try {
//			Thread.sleep(3000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
		
		//获取隐藏域和session中的token值
		String requestToken = request.getParameter("requestToken");
		HttpSession session = request.getSession();
		String sessionToken = (String)session.getAttribute("sessionToken");
		
		//比较隐藏域和session中的token值是否一致
		if(sessionToken != null && sessionToken.equals(requestToken)){
			//如果一致，则受理请求，且清除session中的sessionToken属性
			session.removeAttribute("sessionToken");
		}else{
			//如果不一致，则直接重定向到提示页面
			response.sendRedirect(request.getContextPath()+"/token/info.jsp");
			return;
		}
		
		String username = request.getParameter("username");
		System.out.println("name: "+username);
		
		request.getRequestDispatcher("/token/success.jsp")
				.forward(request, response);
	}

}
