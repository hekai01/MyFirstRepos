package com.xykj.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午9:55:05
 */
@RestController
public class Test2 {
	
	@RequestMapping("/test")
	public String hi(){
		System.out.println("测试....");
		return "12580.......";
	}
}
