package com.xykj.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午9:17:00
 */
/**
 * @RestController 等同于@Controller+@ResponseBody
 * @EnableAutoConfiguration 让 Spring Boot 根据应用所声明的依赖来对 Spring 框架进行自动配置
 */
@RestController
@EnableAutoConfiguration
public class HelloController {
	
	@RequestMapping("/hello")
	public String hello(){
		System.out.println("Hello SpringBoot!");
		return "Hello SpringBoot!Java11欢迎你....";
	}
	
	public static void main(String[] args) {
		/**
		 * 会初始化当前类的对象
		 */
		SpringApplication.run(HelloController.class, args);
	}
}
