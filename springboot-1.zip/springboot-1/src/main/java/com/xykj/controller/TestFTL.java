package com.xykj.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午10:28:53
 */
@Controller
public class TestFTL {
	
	@RequestMapping("/ftl")
	public String testFTL(Map<String,Object> map){
		System.out.println("Test FTL....");
		map.put("name", "新研科技");
		map.put("sex", "1");
		List<String> listResult = new ArrayList<String>();
		listResult.add("张三");
		listResult.add("李四");
		map.put("userlist", listResult);
		return "index";
	}
}
