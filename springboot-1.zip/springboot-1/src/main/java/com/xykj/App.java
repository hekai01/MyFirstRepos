package com.xykj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午9:59:38
 */
//最常用的启动SpringBoot的方式
//可以扫描当前包中和其子包中的所有的类
@SpringBootApplication
public class App {
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
}
