package com.xykj.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午9:51:38
 */
@ComponentScan(basePackages={"com.xykj.controller2","com.xykj.controller"})
@EnableAutoConfiguration
public class App {
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
}
