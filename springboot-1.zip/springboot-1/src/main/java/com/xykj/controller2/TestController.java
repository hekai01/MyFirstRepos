package com.xykj.controller2;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午10:01:01
 */
@RestController
public class TestController {
	
	@RequestMapping("/test1")
	public String test1(){
		System.out.println("test1...01");
		return "test1.....";
	}
}
