package com.xykj.controller2;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午9:49:56
 */
@RestController
public class HelloContrller2 {
	
	@RequestMapping("/index")
	public String helloSpringBoot(){
		System.out.println("新研科技SpringBoot2.0........");
		return "Java11最棒........";
	}
}
