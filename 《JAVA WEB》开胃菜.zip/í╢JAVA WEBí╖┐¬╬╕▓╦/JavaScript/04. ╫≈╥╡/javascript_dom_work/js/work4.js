window.onload = function() {
	// 城市数据
	var cityData = new Array();
	cityData[1] = ["石家庄", "邯郸", "唐山", "廊坊"];
	cityData[2] = ["沈阳", "大连", "鞍山", "抚顺"];
	cityData[3] = ["济南", "德州", "聊城", "菏泽"];
	
	var province = document.getElementById("province");
	// 省份选择事件
	province.onchange = function() {
		// 获取对应省份的城市数据
		var data = cityData[this.value];
		// 获取city
		var city = document.getElementById("city");
		city.innerHTML = "";  // 清空option
		// 添加默认选项
		var op = document.createElement("option");
		op.setAttribute("value", 0);
		op.innerHTML = "请选择";
		city.appendChild(op);
		// 添加城市选项
		for(var i = 0; i < data.length; i++) {
			op = document.createElement("option");
			op.setAttribute("value", i + 1);
			op.innerHTML = data[i];
			city.appendChild(op);
		}
	}
}