window.onload = function() {
	var addBtn = document.getElementById("addBtn");
	var empTable = document.getElementById("empTable");
	
	// 新增员工
	addBtn.onclick = function() {
		// 获取参数
		var name = document.getElementById("name").value;
		var email = document.getElementById("email").value;
		var sal = document.getElementById("sal").value;
		
		// 创建行
		var tr = document.createElement("tr");
		// name
		var td = document.createElement("td");
		td.ondblclick = function() {
			editInput(this);
		};
		td.innerHTML = name;
		tr.appendChild(td);
		// email
		td = document.createElement("td");
		td.ondblclick = function() {
			editInput(this);
		};
		td.innerHTML = email;
		tr.appendChild(td);
		// salary
		td = document.createElement("td");
		td.ondblclick = function() {
			editInput(this);
		};
		td.innerHTML = sal;
		tr.appendChild(td);
		// delete
		td = document.createElement("td");
		td.innerHTML = "<a href='javascript:void(0)' onclick='del(this)'>Delete</a>";
		tr.appendChild(td);
		
		// 添加行
		empTable.appendChild(tr);
	}
}

// 删除行
function del(td) {
	// 获取表
	var empTable = document.getElementById("empTable");
	// 获取行
	var tr = td.parentNode.parentNode;
	console.log(tr);
	console.log(empTable);
	empTable.removeChild(tr);
}

// 进入编辑状态
function editInput(td) {
	// 获取td的文本内容
	var content = td.innerHTML;
	// 创建文本框
	var editInput = document.createElement("input");
	editInput.setAttribute("type", "text");
	// 绑定失去焦点事件
	editInput.onblur = function() {
		var editContent = this.value;
		td.innerHTML = editContent;  // 清空td并且将编辑后的内容显示在td
	};
	editInput.value = content;
	td.innerHTML = "";  // 清空td
	td.appendChild(editInput);
}
