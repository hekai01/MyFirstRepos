window.onload = function() {
	var checkAllCB = document.getElementById("checkAllCB");
	
	var items = document.getElementsByName("items");
	
	var checkAllBtn = document.getElementById("checkAllBtn");
	var checkclearAllBtn = document.getElementById("checkclearAllBtn");
	var checkInverseBtn = document.getElementById("checkInverseBtn");
	
	// 全选/全不选单击事件
	checkAllCB.onclick = function() {
		for(var i = 0; i < items.length; i++) {
			items[i].checked = this.checked;
		}
	};
	
	// 爱好选项单击事件
	for(var i = 0; i < items.length; i++) {
		items[i].onclick = checkAllCBIsChecked;
	}
	
	// 全选事件
	checkAllBtn.onclick = function() {
		for(var i = 0; i < items.length; i++) {
			items[i].checked = true;
			checkAllCB.checked = true;
		}
	};
	
	// 全不选事件
	checkclearAllBtn.onclick = function() {
		for(var i = 0; i < items.length; i++) {
			items[i].checked = false;
			checkAllCB.checked = false;
		}
	}
	
	// 反选事件
	checkInverseBtn.onclick = function() {
		// 全部反选
		for(var i = 0; i < items.length; i++) {
			items[i].checked = !items[i].checked;
		}
		// 判断是否选中全选/全不选
		checkAllCBIsChecked(items);
	}
}

// 判断全选/全不选是否需要被选中
function checkAllCBIsChecked() {
	var items = document.getElementsByName("items");
	var count = 0;  // 选中数量
	for(var i = 0; i < items.length; i++) {
		if(items[i].checked == true) {
			count++;
		}
	}
	if(count == items.length) {
		checkAllCB.checked = true;  // 全选选中
	} else {
		checkAllCB.checked = false;  // 全选不选中
	}
}