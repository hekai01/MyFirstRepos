window.onload = function() {
	var myform = document.getElementById("myform");
	var username = document.getElementById("username");
	var pwd = document.getElementById("pwd");
	var confirmPwd = document.getElementById("confirmPwd");
	
	// 表单提交事件
	myform.onsubmit = function() {
		// 清空所有的错误提示信息
		var spans = document.getElementsByTagName("span");
		for(var i = 0; i < spans.length; i++) {
			spans[i].remove();
			i--;  // 没删除一个spans.length会减少长度
		}
		
		var isSubmit = true;  // 表单是否可以提交
		// 用户名非空判断
		if(username.value == null || username.value == "") {
			isSubmit = false;
			// 创建错误提示信息
			var span = document.createElement("span");
			span.innerHTML = "<font color='red'>用户名不能为空</font>";
			// 将错误信息添加到文本框之后
			username.parentNode.appendChild(span);
		}
		// 密码非空判断
		if(pwd.value == null || pwd.value == "") {
			isSubmit = false;
			// 创建错误提示信息
			var span = document.createElement("span");
			span.innerHTML = "<font color='red'>密码不能为空</font>";
			// 将错误信息添加到文本框之后
			pwd.parentNode.appendChild(span);
		}
		// 确认密码非空判断
		if(confirmPwd.value == null || confirmPwd.value == "") {
			isSubmit = false;
			// 创建错误提示信息
			var span = document.createElement("span");
			span.innerHTML = "<font color='red'>确认密码不能为空</font>";
			// 将错误信息添加到文本框之后
			confirmPwd.parentNode.appendChild(span);
		}
		// 确认密码与密码不一致判断
		if(confirmPwd.value != null && confirmPwd.value != "") {
			if(confirmPwd.value != pwd.value) {
				isSubmit = false;
				// 创建错误提示信息
				var span = document.createElement("span");
				span.innerHTML = "<font color='red'>确认密码与密码不一致</font>";
				// 将错误信息添加到文本框之后
				confirmPwd.parentNode.appendChild(span);
			}
		}
		return isSubmit;
	}
}
