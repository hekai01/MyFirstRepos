package com.xykj.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
/**
 * @RestController注解，表示所有的方法返回JSON格式
 * @TODO
 * @author Administrator
 * @date 2018年9月28日上午10:58:59
 */
@RestController
public class HelloController {
	@RequestMapping("/hello")
	public String  hello(){
		System.out.println("Hello SpringBoot");
		return "Hello SpringBoot Java11";
	}
	/*public static void main(String[] args) {
		SpringApplication.run(HelloController.class, args);//标示该类作为启动类
	}*/
}
