package com.xykj.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
public class GlobalExceptionHandler {
//	@ExceptionHandler(RuntimeException.class)
//	@ResponseBody
//	public Map<String,Object> exceptionHandler(){
//		Map<String,Object> map=new HashMap<String,Object>();
//		map.put("errorCode","101");
//		map.put("errorMsg","系统错误1");
//		return map;
//	}
//	
//	@ExceptionHandler(RuntimeException.class)
//	@ResponseBody
//	public ModelMap exceptionHandler2(){
//		ModelMap map=new ModelMap();
//		map.put("errorCode","101");
//		map.put("errorMsg","系统错误2");
//		return map;
//	}
	
	@ExceptionHandler(RuntimeException.class)
	public String exceptionHandler3(){
		Map<String,Object> map=new HashMap<String,Object>();
		map.put("errorCode","101");
		map.put("errorMsg","系统错误");
		return "erro";//error 会报timestamp错误
	}
}
