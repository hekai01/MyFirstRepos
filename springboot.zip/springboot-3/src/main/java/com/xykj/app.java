package com.xykj;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
/**
 * SpringBoot 是一个快速开发的框架,能够快速的整合第三方框架，简化XML配置，全部采用注解形式，内置Tomcat容器,
 * 帮助开发者能够实现快速开发，SpringBoot的Web组件 默认集成的是SpringMVC框架。SpringMVC是控制层。
 * @TODO  SpringCloud是一套完整的微服务解决框架。
 * https://otto.takari.io/content/sites/m2e.extras/m2eclipse-mavenarchiver/0.17.2/N/LATEST/
 * @author Administrator
 * @date 2018年9月28日下午9:08:30
 */
@SpringBootApplication
public class app {
	public static void main(String[] args) {
		SpringApplication.run(app.class, args);
	}
}
