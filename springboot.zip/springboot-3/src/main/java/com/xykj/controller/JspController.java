package com.xykj.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class JspController {
	@RequestMapping("/index")
	public String helloJsp(Map<String,Object>map){
		map.put("name", "张学友");
		int i=10/0;
		return "index";
	}
}
