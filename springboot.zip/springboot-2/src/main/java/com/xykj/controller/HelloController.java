package com.xykj.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController//返回的内容为json对象
public class HelloController {
	@RequestMapping("/hello")
	public String hello(){
		System.out.println("hello springboot");
		return "yeyeye  springboot hello";
	}
}
