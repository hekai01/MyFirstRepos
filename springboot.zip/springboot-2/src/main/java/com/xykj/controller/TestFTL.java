package com.xykj.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
/**
 * freemarker 渲染web视图
 * @TODO springboot默认的模板配置路径为：src/main/resources/templates,可在后续各模板引擎的配置属性中查询并修改
 * @author Administrator
 * @date 2018年9月28日下午8:16:38
 */
@Controller//ftl不需要json返回
public class TestFTL {
	@RequestMapping("/ftl")
	public String testFTL(Map<String,Object>map){
		System.out.println("test ftl...");
		map.put("name","新研科技");
		return "index";
	}
}
