package com.xykj.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController2 {
	@RequestMapping("/index")
	public String hello(){
		System.out.println("hello springboot");
		return "hello  springboot!";
	}
}
