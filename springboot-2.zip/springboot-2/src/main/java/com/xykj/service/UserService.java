package com.xykj.service;

import java.util.List;

import com.xykj.pojo.User;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午11:25:21
 */
public interface UserService {
	
	public List<User> getUsers();
}
