package com.xykj.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.xykj.pojo.User;
import com.xykj.service.UserService;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午11:26:18
 */
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<User> getUsers() {
		List<User> list = jdbcTemplate.query("SELECT * FROM USERS", new BeanPropertyRowMapper<User>(User.class));
		return list;
	}

}
