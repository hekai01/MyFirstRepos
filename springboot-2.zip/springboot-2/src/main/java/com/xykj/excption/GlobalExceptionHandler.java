package com.xykj.excption;

import java.util.HashMap;
import java.util.Map;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午10:52:33
 */
@ControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(RuntimeException.class)
	@ResponseBody
	public ModelMap exceptionHandler() {
		ModelMap map = new ModelMap();
		//Map<String, Object> map = new HashMap<String, Object>();
		map.put("errorCode", "101");
		map.put("errorMsg", "系統错误!");
		System.out.println("出错了。。。。");
		return map;
	}

}
