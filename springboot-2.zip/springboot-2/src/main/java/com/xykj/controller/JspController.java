package com.xykj.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.xykj.service.UserService;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午10:44:04
 */
@Controller
public class JspController {
	@Autowired
	private UserService userService;
	
	@RequestMapping("/index")
	public String helloJSP(Map<String,Object> map){
		map.put("name", "张学友");
		//int i = 10/0;
		return "index";
	}
	
	@RequestMapping("/getUsers")
	public String testJdbcTemplate(Map<String,Object> map){
		map.put("list", userService.getUsers());
		return "list";
	}
}
