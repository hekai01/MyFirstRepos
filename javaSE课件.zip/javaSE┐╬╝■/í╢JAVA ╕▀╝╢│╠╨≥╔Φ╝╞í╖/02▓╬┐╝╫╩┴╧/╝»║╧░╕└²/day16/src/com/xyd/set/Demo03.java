/**
 * 
 */
package com.xyd.set;

import java.util.HashSet;
import java.util.Set;

/**
 * @author scott
 * @date 2017年12月19日下午3:33:29
 * @version 
 * @description  对于要存放到Set集合中的对象，
 *            对应的类一定要重写equals()和hashCode(Object obj)方法以实现对象相等规则。
 *            
 *            如果没有重写这两个方法  就是 可以添加多个
 *            
 *            写了这2 个方法  可以自己重写比较规则 （不能添加重复）
 */
public class Demo03 {

	public static void main(String[] args) {
		
		Set<User> hashSet = new HashSet<>();

		//如果年龄相等  就是同一  对象  ?   重写 equals  hashCode()
		hashSet.add(new User(11, "aa"));
		hashSet.add(new User(11, "cc"));

		for (User user : hashSet) {
			System.out.println(user);
		}
		
		
	}
}
