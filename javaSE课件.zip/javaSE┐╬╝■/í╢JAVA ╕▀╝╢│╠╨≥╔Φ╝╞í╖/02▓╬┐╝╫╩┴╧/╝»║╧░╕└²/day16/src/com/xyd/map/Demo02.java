/**
 * 
 */
package com.xyd.map;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author scott
 * @date 2017年12月19日下午4:14:31
 * @version
 * @description map的遍历 1.keySet 遍历 获取 key 的set 集 通过 key 拿到 value
 * 
 */
public class Demo02 {

	public static void main(String[] args) {

		Map<String, Integer> map = new HashMap<>();

		// 添加
		map.put("aa", 11);
		map.put("bb", 22);
		map.put("cc", 33);

		//返回此Map中包含的值的Collection集。
		Collection<Integer> values = map.values();
		for (Integer integer : values) {
			System.out.println(integer);
		}
		
		// iterForKeySet(map);

		iterForEntrySet(map);

	}

	/**
	 * 通过  entrySet 来迭代 
	 */
	private static void iterForEntrySet(Map<String, Integer> map) {
		Set<Entry<String, Integer>> entrySet = map.entrySet();

		for (Entry<String, Integer> entry : entrySet) {
			String key = entry.getKey();
			Integer value = entry.getValue();
			
			System.out.println("key--->" + key + ", value--->" + value);
		}
	}

	/**
	 * 同过 keyset 来迭代 Map
	 */
	private static void iterForKeySet(Map<String, Integer> map) {
		Set<String> keySet = map.keySet();

		// 遍历set
		for (String key : keySet) {

			System.out.println("key--->" + key + ", value--->" + map.get(key));
		}

		System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
		Iterator<String> iter = keySet.iterator();

		while (iter.hasNext()) {
			String key = iter.next();
			System.out.println("key--->" + key + ", value--->" + map.get(key));

		}
	}
}
