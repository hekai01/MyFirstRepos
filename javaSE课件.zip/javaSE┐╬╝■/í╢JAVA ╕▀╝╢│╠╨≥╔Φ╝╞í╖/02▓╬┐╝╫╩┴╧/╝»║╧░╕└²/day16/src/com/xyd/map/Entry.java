/**
 * 
 */
package com.xyd.map;

/**
 * @author scott
 * @date 2017年12月19日下午4:31:43
 * @version 
 * @description 
 */
public class Entry {

	Object key;
	
	Object value;
	
	public Entry() {
	}

	public Entry(Object key, Object value) {
		this.key = key;
		this.value = value;
	}
}
