/**
 * 
 */
package com.xyd.map;

/**
 * @author scott
 * @date 2017年12月19日下午4:32:53
 * @version
 * @description 自己实现 map 效率很低  没有hashCode  
 * 
 */
public class MyMap01 {

	// 存放 容器
	private Entry[] arr = new Entry[99];

	// 个数
	private int size;

	public int size() {
		return size;
	}

	/**
	 * map 的put方法
	 */
	public void put(Object key, Object value) {

		Entry entry = new Entry(key, value);
		
		for (int i = 0; i < size; i++) {
			if (key.equals(arr[i].key)) {
				arr[i].value = value;
				return;
			}
		}

		arr[size++] = entry;
	}

	/**
	 * 通过 key 来获取 
	 */
	public Object get(Object key) {

		for (int i = 0; i < size; i++) {
			if (key.equals(arr[i].key)) {
				return arr[i].value;
			}
		}
		return null;
	}

	/**
	 * 通过  key 移除 
	 */
	public void remove(Object key) {

		int index = 0;
		for (int i = 0; i < size; i++) {
//			Entry entry = arr[i];
			if (key.equals(arr[i].key)) {
				index = i;
			}
		}
		
		int numMoved = size - index - 1;
		System.arraycopy(arr, index + 1, arr, index, numMoved);
		arr[--size] = null; 
	}
	
	public boolean containskey(Object key) {
		
		for (int i = 0; i < size; i++) {
			if (key.equals(arr[i].key)) {
				return true;
			}
		}
		return false;
	}

	public static void main(String[] args) {

		MyMap01 myMap01 = new MyMap01();

		// 添加
		myMap01.put("aa", "11");
		myMap01.put("aa", "22");
		myMap01.put("bb", "22");

		//移除
//		myMap01.remove("aa");
		
		// 大小
		System.out.println(myMap01.size());
		
		//是否包含
		System.out.println(myMap01.containskey("bb"));

		// 通过 key获取 value
		System.out.println(myMap01.get("aa"));
	}

}
