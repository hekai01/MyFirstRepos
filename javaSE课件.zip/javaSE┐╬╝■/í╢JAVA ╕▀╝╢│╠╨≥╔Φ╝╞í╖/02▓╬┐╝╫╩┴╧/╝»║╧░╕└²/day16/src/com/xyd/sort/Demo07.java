/**
 * 
 */
package com.xyd.sort;

import java.util.Comparator;
import java.util.Set;
import java.util.TreeMap;

/**
 * @author scott
 * @date 2017年12月20日上午10:47:04
 * @version 
 * @description  TreeMap 的键 来排序 (通过 构造器  （比较器）)
 */
public class Demo07 {

	public static void main(String[] args) {
		
		TreeMap< Gril, String> treeMap = new TreeMap<>(new Comparator<Gril>() {

			@Override
			public int compare(Gril o1, Gril o2) {
				// o1 = o2 相等  返回的是  0 
				if (o1.getAge() == o2.getAge()) {
					return 0;
				}
				// o1 < o2   返回的是  -1 
				
				if (o1.getAge() < o2.getAge()) {
					return -1;
				}
				// o1 > o2 相等  返回的是  1 
				return 1;
			}
		});
		
		treeMap.put(new Gril(28, 80, "baby"), "xyd");
		treeMap.put(new Gril(22, 70, "关晓彤"), "xyd");
		treeMap.put(new Gril(38, 85, "高圆圆"), "xyd");
		treeMap.put(new Gril(44, 90, "陈慧琳"), "xyd");
		
		Set<Gril> keySet = treeMap.keySet();
		
		for (Gril gril : keySet) {
			System.out.println(gril);
		}
		
	}
}
