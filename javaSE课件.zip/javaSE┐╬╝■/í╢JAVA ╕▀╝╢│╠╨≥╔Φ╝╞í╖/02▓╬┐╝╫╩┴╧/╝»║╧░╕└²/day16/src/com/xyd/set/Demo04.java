/**
 * 
 */
package com.xyd.set;

import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * @author scott
 * @date 2017年12月19日下午3:41:53
 * @version 
 * @description  LinkedHashSet(了解)
 */
public class Demo04 {

	public static void main(String[] args) {
		
		// arraylist  和  LinkedList  用法差不多   新曾了几个方法  addFirst  removeFirst
		
		//HashSet 和 LinkedHashSet
		
		//创建   set - >Collection
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
		
		//添加 
		linkedHashSet.add("aa");
		linkedHashSet.add("bb");
		
		//移除
		linkedHashSet.remove("aa");
		
		//通过迭代器来跌打
		Iterator<String> iterator = linkedHashSet.iterator();
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		System.out.println(linkedHashSet.size());
		
		
	}
}
