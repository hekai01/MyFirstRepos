/**
 * 
 */
package com.xyd.demo03;

/**
 * @author scott
 * @date 2017年12月19日上午10:51:32
 * @version 
 * @description 
 */
public class TestMyInterfaceImpl {

	public static void main(String[] args) {
		MyInterfaceImpl<Integer> myInterfaceImpl = new MyInterfaceImpl<>();
	}
}
