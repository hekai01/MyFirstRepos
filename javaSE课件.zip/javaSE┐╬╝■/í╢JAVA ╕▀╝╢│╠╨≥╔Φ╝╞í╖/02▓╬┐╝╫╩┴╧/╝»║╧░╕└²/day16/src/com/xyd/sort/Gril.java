/**
 * 
 */
package com.xyd.sort;

/**
 * @author scott
 * @date 2017年12月20日上午10:27:23
 * @version 
 * @description 
 */
public class Gril {

	private int age;
	
	private int hot;
	
	private String name;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getHot() {
		return hot;
	}

	public void setHot(int hot) {
		this.hot = hot;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Gril(int age, int hot, String name) {
		super();
		this.age = age;
		this.hot = hot;
		this.name = name;
	}
	
	public Gril() {
	}

	@Override
	public String toString() {
		return "Gril [age=" + age + ", hot=" + hot + ", name=" + name + "]";
	}
	
}
