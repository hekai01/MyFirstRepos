/**
 * 
 */
package com.xyd.demo02;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author scott
 * @date 2017年12月19日上午10:14:11
 * @version 
 * @description 
 */
public class TestList03 {

	public static void main(String[] args) {
		
		/**
		 *  1.创建对象 添加到集合中去
		 *  
		 *  2.操作 集合的 方法 
		 */
		
		ArrayList arrayList = new ArrayList<>();
		
		arrayList.add(new Worker("张三", 18, 3000d)); 
		arrayList.add(new Worker("李四", 20, 3500d)); 
		arrayList.add(new Worker("王五", 45, 3200d));
		
		//添加工人
		arrayList.add(1, new Worker("老赵", 15, 2300d));
		
		//for遍历 打印工人信息
		
		for (int i = 0; i < arrayList.size(); i++) {
			
			System.out.println(arrayList.get(i));
			
		}
		
		System.out.println("*********************");
		//利用迭代遍历，对List 中所有的工人调用showInfo方法。
		Iterator iterator = arrayList.iterator();
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
	}
}
