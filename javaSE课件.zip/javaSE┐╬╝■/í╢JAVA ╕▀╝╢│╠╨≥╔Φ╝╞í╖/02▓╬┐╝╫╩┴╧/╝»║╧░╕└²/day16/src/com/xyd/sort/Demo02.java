/**
 * 
 */
package com.xyd.sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月20日上午9:47:24
 * @version 
 * @description  自己写  实现了 Comparable 接口可以排序(自然排序) 
 */
public class Demo02 {

	public static void main(String[] args) {
		
		List<Sister> list = new ArrayList<>();
		
		list.add(new Sister(44, 70, "黄蓉"));
		list.add(new Sister(22, 45, "如花"));
		list.add(new Sister(22, 80, "王小米"));
		list.add(new Sister(33, 75, "周芷若"));
		
		//排序
		Collections.sort(list);
		
		for (Sister sister : list) {
			System.out.println(sister);
		}
		
	}
	
}
