/**
 * 
 */
package com.xyd.list;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;

/**
 * @author scott
 * @date 2017年12月18日下午2:49:28
 * @version 
 * @description ArrayList 的反转 (和数组的反转一样)
 */
public class List03 {

	public static void main(String[] args) {
		
		List list = new ArrayList<>();

		list.add("aa");
		list.add(12);
		list.add(3.4f);
		list.add("cc");
		
//		test01(list);
		test02(list);
	
	}

	/**
	 * ListIterator
	 */
	private static void test02(List list) {
		// int i = cursor - 1;   直接给开始位置的 长度  list.size()  
		ListIterator listIterator = list.listIterator(list.size());
		while (listIterator.hasPrevious()) {
			System.out.println(listIterator.previous());
		}
	}

	/**
	 * for循环来反转
	 */
	private static void test01(List list) {
		
		
		for (int i = list.size()-1; i >= 0; i--) {
			
			System.out.println(list.get(i));
			
		}
		
	}
}
