/**
 * 
 */
package com.xyd.coll;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月20日上午10:57:13
 * @version
 * @description Collections 的工具类的用方法
 * 
 *              max min
 */
public class Demo02 {

	public static void main(String[] args) {

		List<Integer> list = new ArrayList<>();

		list.add(34);
		list.add(22);
		list.add(6);
		list.add(3);

		// 3  6  22  34  
		 Collections.sort(list);
		// 二分查找(一定要实现排序) 效率会 比 indexOf
		int binarySearch = Collections.binarySearch(list, 22);

		System.out.println(binarySearch);

		// 元素 右移
		// [34, 22, 6, 3]
		System.out.println(list);
		Collections.rotate(list, 3);
		// [22, 6, 3, 34]
		System.out.println(list);

		// 填充 [23, 23, 23, 23] 把 有的 都替换成 23
		// Collections.fill(list, 23);
		// System.out.println(list);

		Collections.replaceAll(list, 22, 55);
		System.out.println(list);

		int indexOf = list.indexOf(22);
		System.out.println(indexOf);

		// 返回组大值
		Integer max = Collections.max(list);
		Integer min = Collections.min(list);

		System.out.println("max : " + max);
		System.out.println("min : " + min);

	}
}
