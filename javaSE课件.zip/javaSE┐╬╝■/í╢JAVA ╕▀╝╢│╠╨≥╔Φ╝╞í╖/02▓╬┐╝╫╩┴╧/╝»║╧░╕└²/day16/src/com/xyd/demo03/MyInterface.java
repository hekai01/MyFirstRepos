/**
 * 
 */
package com.xyd.demo03;

/**
 * @author scott
 * @date 2017年12月19日上午10:49:57
 * @version 
 * @description 
 */
public interface MyInterface<T> {

	T next();
	
}
