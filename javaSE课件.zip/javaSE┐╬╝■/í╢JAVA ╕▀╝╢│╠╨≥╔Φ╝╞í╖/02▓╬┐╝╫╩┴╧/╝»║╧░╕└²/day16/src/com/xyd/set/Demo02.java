/**
 * 
 */
package com.xyd.set;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author scott
 * @date 2017年12月19日下午3:20:24
 * @version
 * @description {2,3,4,5,3,1,34,2}; 去重复?
 * 
 *              1. 用ArrayList 来操作
 * 
 *                 contains
 * 
 *              2. 用 HashSet 操作
 * 
 */
public class Demo02 {

	public static void main(String[] args) {

		int[] arr = { 2, 3, 4, 5, 3, 1, 34, 2 };

		List<Integer> list = arrToList(arr);

		//第一种方法  
		List<Integer> newList = removeReat(list);
		
		HashSet<Integer> set = removeReat1(list);
		
		for (Integer integer : set) {
			System.out.println(integer);
		}

	}

	/**
	 * 用set 区重复
	 */
	private static HashSet<Integer> removeReat1(List<Integer> list) {
		// arr 转成 List
		HashSet<Integer> set = new HashSet<>();

		for (int i = 0; i < list.size(); i++) {
			set.add(list.get(i));
		}
		return set;
	}

	/**
	 * arr 转成 List
	 */
	private static List<Integer> arrToList(int[] arr) {
		// arr 转成 List
		List<Integer> list = new ArrayList<>();

		for (int i = 0; i < arr.length; i++) {
			list.add(arr[i]);
		}
		return list;
	}

	/**
	 * 区重复
	 */
	private static List<Integer> removeReat(List<Integer> list) {

		List<Integer> arrayList = new ArrayList<>();

		for (int i = 0; i < list.size(); i++) {
			Integer integer = list.get(i);
			// 判断
			if (!arrayList.contains(integer)) { // 不包含 就添加到arrayList
				arrayList.add(integer);
			}
		}

		return arrayList;
	}

}
