/**
 * 
 */
package com.xyd.coll;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月20日上午10:51:57
 * @version 
 * @description  Collections 的工具类的用方法
 *               
 *               排序  sort()
 *               
 *               反转  reverse
 */
public class Demo01 {

	public static void main(String[] args) {

		//接口                                                  实现类
		List<String> list = new ArrayList<String>();
		
		list.add("aa");
		list.add("bb");
		list.add("cc");
		list.add("dd");
		
		//反转 
//		Collections.reverse(list);00000000
		//下标 的 2个元素交换
//		Collections.swap(list, 2, 3);
		
		//随机进行排序  
		Collections.shuffle(list);
		
		for (String string : list) {
			System.out.println(string);
		}
		
	}
}
