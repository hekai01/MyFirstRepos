/**
 * 
 */
package com.xyd.map;

import java.util.LinkedList;

/**
 * @author scott
 * @date 2017年12月19日下午4:32:53
 * @version
 * @description 自己实现 map 使用hashCode  效率 高 
 * 
 *              map 的底层实现是: 数组 + 链表
 * 
 *              ArrayList 底层实现 数组
 * 
 *              LinkedList 底层实现 链表
 * 
 */
public class MyMap02 {

	private LinkedList[] arr = new LinkedList[99];

	private int size;

	public int size() {
		return size;
	}

	/**
	 * 添加 k 和 value
	 */
	public void put(Object key, Object value) {

		// 通过 hashCode 来确定 放在那个位置

		int a = getHashCode(key);
		Entry entry = new Entry(key, value);

		if (arr[a] == null) { // 第一次进来的操作

			LinkedList list = new LinkedList();
			list.add(entry);
			arr[a] = list;
		} else { // hashCode 有重复 的操作
			LinkedList list = arr[a];
			list.add(entry);
		}
		size++;
	}

	/**
	 * 获取 key 的hashCode 值
	 */
	private int getHashCode(Object key) {
		int a = key.hashCode() % arr.length;
		return a;
	}

	/**
	 * 通过 key 获取 value 值
	 */
	public Object get(Object key) {

		int hashCode = getHashCode(key);

		LinkedList list = arr[hashCode];

		for (int i = 0; i < arr.length; i++) {

			Entry entry = (Entry) list.get(i);

			if (entry.key.equals(key)) {
				return entry.value;
			}
		}
		return null;
	}

	public boolean containsKey(Object key) {
		int hashCode = getHashCode(key);

		LinkedList list = arr[hashCode];

		for (int i = 0; i < arr.length; i++) {

			Entry entry = (Entry) list.get(i);

			if (entry.key.equals(key)) {
				return true;
			}
		}

		return false;
	}

	public void remove(Object key) {

		int hashCode = getHashCode(key);
		
		LinkedList list= arr[hashCode];
		
		for (int i = 0; i < list.size(); i++) {
			
			Entry entry = (Entry) list.get(i);
			if (entry.key.equals(key)) {
				list.remove(entry);
			}
		}
		
		size--;
	}
	
	
	public static void main(String[] args) {

		MyMap02 myMap02 = new MyMap02();

		myMap02.put("aa", 12);
		myMap02.put("bb", 123);
		
		myMap02.remove("aa");
		System.out.println(myMap02.size());

		System.out.println(myMap02.get("bb"));
		
		System.out.println(myMap02.containsKey("bb"));

	}
}
