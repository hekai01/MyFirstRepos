/**
 * 
 */
package com.xyd.coll;

import java.util.ArrayList;
import java.util.Collections;

/**
 * @author scott
 * @date 2017年12月20日下午2:03:03
 * @version
 * @description
 */
public class Tes {

	public static void main(String[] args) {

		String[] aa = { "黑桃", "红桃", "方块", "梅花" };
		String[] ss = { "A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K" };
		ArrayList<String> arr = new ArrayList();
		for (int i = 0; i < aa.length; i++) {
			for (int j = 0; j < ss.length; j++) {
				arr.add(aa[i] + ss[j]);
			}
		}
		arr.add("大王");
		arr.add("小王");
		Collections.shuffle(arr);
		System.out.println(arr);

		ArrayList 小红 = new ArrayList();
		ArrayList 小明 = new ArrayList();
		ArrayList 小米 = new ArrayList();

		for (int i = 0; i < arr.size(); i++) {

			if (i % 3 == 0) {
				小红.add(arr.get(i));
			} else if (i % 3 == 1) {
				小明.add(arr.get(i));
			} else if (i % 3 == 2) {
				小米.add(arr.get(i));
			}
		}
		System.out.println("小红的排" + 小红);
		System.out.println("小明的排" + 小明);
		System.out.println("小米的排" + 小米);

		for (int i = arr.size() - 3; i < arr.size(); i++) {
			System.out.println(arr.get(i));

		}
	}

}
