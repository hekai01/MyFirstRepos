/**
 * 
 */
package com.xyd.list;

import java.util.ArrayList;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月18日下午2:18:49
 * @version 
 * @description  List 的接口中的方法
 *          
 *          List是接口不能new   
 *             |- ArrrayList   
 *                     新增 的方法  :  
 *                      add(int index, E element) 
							在列表中指定的位置上插入指定的元素（可选操作）。 
 *                           
 *                      get(int index) 
						         返回此列表中指定位置的元素。 
						         
						indexOf(Object o) 
							返回此列表中指定元素的第一个出现的索引，或-如果此列表不包含元素，或- 1。 
						         
						E remove(int index) 
                                                                   移除此列表中指定位置的元素（可选操作）。         
                                                                   
                        ListIterator<E> listIterator()  
                                                                    
 *             |- LinkedList 
 *             |- Vector  
 */
public class List01 {

	public static void main(String[] args) {
		
		//创建 ArrayList  

		List list = new ArrayList<>();
		//添加
		list.add("aa");
		list.add(12);
		list.add("马化腾");
		list.add("贾跃亭");
		
		//给指定位置添加元素
//		list.add(1, "cc");  //List 新增方法
		
		//移除
//		list.remove("aa"); 
		
		list.remove(1); //List 新增方法
		//几个元素  size()
		
		System.out.println("size : " + list.size());
		
		//获取元素  get(index)   
		Object o1 = list.get(1);  //List的新增方法
//		System.out.println(list.get(2));
		System.out.println(o1);
		
		// 获取对象 在 list 中的下标 位置   没有 这个元素  返回的  -1
	    int indexOf = list.indexOf("aa");
		
	    System.out.println(indexOf);
	    
	    //是否 包含 
	    boolean contains = list.contains("aa");
	    System.out.println(contains);
	
	}
}
