/**
 * 
 */
package com.xyd.sort;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * @author scott
 * @date 2017年12月20日上午10:23:53
 * @version 
 * @description  通过 TreeSet 元素进行排序(元素要实现comparable接口) 进行排序 
 */
public class Demo04 {

	public static void main(String[] args) {
		
		TreeSet<Sister> treeSet = new TreeSet<>();
		
		treeSet.add(new Sister(44, 70, "黄蓉"));
		treeSet.add(new Sister(22, 45, "如花"));
		treeSet.add(new Sister(22, 80, "王小米"));
		treeSet.add(new Sister(33, 75, "周芷若"));
		
		for (Sister sister : treeSet) {
			System.out.println(sister);
		}
		
	}
}
