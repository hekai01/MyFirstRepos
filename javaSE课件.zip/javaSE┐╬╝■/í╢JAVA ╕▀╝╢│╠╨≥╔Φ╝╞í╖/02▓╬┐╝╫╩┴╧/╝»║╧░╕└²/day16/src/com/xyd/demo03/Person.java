/**
 * 
 */
package com.xyd.demo03;

/**
 * @author scott
 * @date 2017年12月19日上午10:42:38
 * @version 
 * @description 
 */
public class Person<A3>{

	private A3 money;
	
	private String name;

	public A3 getMoney() {
		return money;
	}

	public void setMoney(A3 money) {
		this.money = money;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Person(A3 money, String name) {
		super();
		this.money = money;
		this.name = name;
	}
	
	public Person() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Person [money=" + money + ", name=" + name + "]";
	}
	
}
