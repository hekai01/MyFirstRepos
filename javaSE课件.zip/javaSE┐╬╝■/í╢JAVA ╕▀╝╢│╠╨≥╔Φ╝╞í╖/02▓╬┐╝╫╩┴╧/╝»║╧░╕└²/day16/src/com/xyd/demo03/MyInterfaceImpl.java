/**
 * 
 */
package com.xyd.demo03;

/**
 * @author scott
 * @date 2017年12月19日上午10:50:29
 * @version 
 * @param <T>
 * @description  泛型接口: 
 *                接口可以给指定的 类型 
 *                
 *                或者 不给类型   接口的实现类 要给泛型 
 *                
 *                用法和泛型类是一样的  
 *                
 */
public class MyInterfaceImpl<T> implements MyInterface<T> {

	@Override
	public T next() {
		return null;
	}

//	@Override
//	public Integer next() {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
