/**
 * 
 */
package com.xyd.demo03;

import java.util.ArrayList;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月19日上午10:28:28
 * @version 
 * @description  为什么要使用泛型? 
 */
public class Demo01 {

	public static void main(String[] args) {
		
		//没有加泛型   数据不安全  省心
		List list = new ArrayList<>();
		
		list.add("aa");
		
		list.add(12);
		
		for (int i = 0; i < list.size(); i++) 
		{
			Object obj =  list.get(i);
			
			if (obj instanceof String) {
				String str = (String) obj;
				System.out.println(str);
			}
		}
		
		//泛型  List<T> T 是个具体的类型 （应用类型）   
		//<> 括号语法  括号中给具体的类型    （集合总 只能添加这一种类型）
		List<String> date = new ArrayList<>();
		
		date.add("aa");
		date.add("bb");
		date.add("cc");
		
	}
}
