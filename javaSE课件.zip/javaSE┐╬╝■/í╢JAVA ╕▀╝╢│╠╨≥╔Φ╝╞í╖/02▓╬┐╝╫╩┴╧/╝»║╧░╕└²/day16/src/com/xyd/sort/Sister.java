/**
 * 
 */
package com.xyd.sort;

/**
 * @author scott
 * @date 2017年12月20日上午9:47:52
 * @version 
 * @description 
 */
public class Sister implements Comparable<Sister>{

	private int age;
	
	private int handsome;
	
	private String name;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getHandsome() {
		return handsome;
	}

	public void setHandsome(int handsome) {
		this.handsome = handsome;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Sister() {
		// TODO Auto-generated constructor stub
	}

	public Sister(int age, int handsome, String name) {
		this.age = age;
		this.handsome = handsome;
		this.name = name;
	}

	@Override
	public String toString() {
		return "Sister [age=" + age + ", handsome=" + handsome + ", name=" + name + "]";
	}

	/**
	 * 比较方法  （比较的是 属性）
	 *   如果返回的是  0  就是  相等
	 *            -1 就是  小
	 *             1  就是  大
	 *  比较 年龄
	 *  自己写比较规则 就好            
	 */
	@Override
	public int compareTo(Sister o) {
		//年龄相等  返回值就是  0
		if (this.getAge() == o.getAge()) {
			
			//如果 年龄 相等  就用几个 handsome 排序 
			if (this.getHandsome() == o.getHandsome()) {
				return 0;
			}
			if (this.getHandsome() < o.getHandsome()) {
				return -1;
			}
			return 1;
		}
		//this 年龄小于  o 返回值就是  -1
		if (this.getAge() < o.getAge()) {
			return -1;
		}
		//this 年龄小于  o 返回值就是  1
		return 1;
	}
	
}
