/**
 * 
 */
package com.xyd.set;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * @author scott
 * @date 2017年12月19日下午3:12:06
 * @version 
 * @description 测试 set 的一些方法
 *               1.不能添加重复的 
 *               2.无序
 *               set 是接口不能直接new  有子类实现 HashSet
 *               
 */
public class Demo01 {

	public static void main(String[] args) {
		
		//创建 子类实现
		Set<String> set = new HashSet<>();

		//添加 
		set.add("aa");
		set.add("cc");
		set.add("dd");
		set.add("ee");
		set.add("ff");
		set.add("gg1");
		
		set.add("ff"); //没有天机进去  不能有重复的  
		
		//删除
		set.remove("aa");
		
		//大小
		System.out.println(set.size());
		
		//是否包含
		System.out.println(set.contains("cc"));
		
		//迭代   set的迭代一定要用 Iterator

		System.out.println("**************");
		Iterator<String> iterator = set.iterator();
		
		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		
		System.out.println("********for*********");
		for (String str: set) {
			System.out.println(str);
		}
		
		
	}
	
	
}
