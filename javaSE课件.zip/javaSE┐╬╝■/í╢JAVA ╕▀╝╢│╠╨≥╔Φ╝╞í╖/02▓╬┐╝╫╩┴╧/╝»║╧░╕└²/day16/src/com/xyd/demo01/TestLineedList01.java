/**
 * 
 */
package com.xyd.demo01;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月19日上午9:39:23
 * @version 
 * @description LinkedList 的方法  和 ArrayList 用法 基本一样 
 *              新增了几个方法 addFrist()  removeFirst()
 */
public class TestLineedList01 {

	public static void main(String[] args) {
		
		List linkedList = new LinkedList();
		
		linkedList.add("aa");
		linkedList.add("bb");
		linkedList.add("cc");
		
		linkedList.forEach(e ->System.out.println(e));
		Iterator iterator2 = linkedList.iterator();
		
		iterator2.hasNext();
		
//		linkedList.remove(1);
		
		Object obj = linkedList.get(0);
		System.out.println(obj);
		
		//新增方法  多态 只能用父类或者接口中的方法   子类或者实现类 新增方法会丢失
		LinkedList linked = null;
		if (linkedList instanceof LinkedList) {
			
			linked = (LinkedList) linkedList;
			
			linked.addFirst("ww");
			
			linked.removeFirst();
		}
		
		System.out.println(linked.getFirst());
		
		//迭代 和 ArrayList 一样
		
		System.out.println("迭代...");
		Iterator iterator = linked.iterator();
		
	    while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
		System.out.println("foreach遍历");
	    for (Object o : linked) {
			System.out.println(o);
		}
	    
	    System.out.println("for遍历");
	    
	    for (int i = 0; i < linked.size(); i++) {
			System.out.println(linked.get(i));
		}
	}
}
