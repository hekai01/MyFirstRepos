/**
 * 
 */
package com.xyd.demo03;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月19日上午11:31:46
 * @version 
 * @description  泛型 的  边界问题
 * 
 *               ? extends Number  可以给 number 和number 子类    
 */
public class Demo04 {

	
	public static void showKey(List<? extends Number> list){
	    System.out.println("泛型测试" + list.get(0));
	}
	
	public static void main(String[] args) {
//		       T 的类型 一定要是  Comparable 的实现类
//		Collections.sort(list); T extends Comparable(接口)
		
		List<Integer> list = new ArrayList<>();
		List<String> list1 = new ArrayList<>();
		
		List<Double> list2 = new ArrayList<>();
		List<Number> list3 = new ArrayList<>();
		
		showKey(list);
		showKey(list2);
		showKey(list3);
		
		
	}
	
	
	
}
