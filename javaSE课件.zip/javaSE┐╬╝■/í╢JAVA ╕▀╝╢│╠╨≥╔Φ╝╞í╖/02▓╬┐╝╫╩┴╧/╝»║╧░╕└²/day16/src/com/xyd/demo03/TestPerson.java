/**
 * 
 */
package com.xyd.demo03;

import com.xyd.demo02.User;

/**
 * @author scott
 * @date 2017年12月19日上午10:43:43
 * @version
 * @description
 */
public class TestPerson {

	public static void main(String[] args) {

		// 泛型 只能给引用类型
		Person<Integer> person = new Person<>();
		person.setMoney(33);
		System.out.println(person.getMoney());

		Person<Double> person1 = new Person<Double>();
		person1.setMoney(33.3d);
		System.out.println(person1.getMoney());

		// 1.7 之前 <> 都要给东西   1.7之后 后面的<>的类型可以省略
		Person<User> p2 = new Person<>();
		
	}
}
