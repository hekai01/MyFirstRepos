/**
 * 
 */
package com.xyd.demo02;

import java.util.ArrayList;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月19日上午9:50:23
 * @version
 * @description
 */
public class TestList02 {

	public static void main(String[] args) {

		// 创建集合

		List list = new ArrayList();

		list.add(new User("aa", 33));
		list.add(new User("bb", 44));
		list.add(new User("cc", 22));

		// 冒泡排序

		for (int i = 0; i < list.size() - 1; i++) {

			for (int j = 0; j < list.size() - 1 - i; j++) {

				User u1 = (User) list.get(j);
				User u2 = (User) list.get(j + 1);

				if (u1.getAge() > u2.getAge()) {

					list.set(j, u2);
					list.set(j + 1, u1);

				}
			}
		}

		// 遍历查看元素
		for (Object object : list) {

			if (object instanceof User) {

				User u = (User) object;

				System.out.println(u);
			}
		}

	}
}
