/**
 * 
 */
package com.xyd.sort;

import java.util.Comparator;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * @author scott
 * @date 2017年12月20日上午10:40:24
 * @version
 * @description 通过 TreeSet的构造 比较器 来进行排序
 * 
 */

public class Demo06 {

	public static void main(String[] args) {

//		GrilComparator grilCom = new GrilComparator();
//		// TreeSet  如果 返回值 是  0  2个对象就是相等    只能添加一个
//		TreeSet<Gril> treeSet = new TreeSet<>(grilCom);
		TreeSet<Gril> treeSet = new TreeSet<>(new Comparator<Gril>() {

			@Override
			public int compare(Gril o1, Gril o2) {
				// o1 = o2 相等  返回的是  0 
				if (o1.getAge() == o2.getAge()) {
					return 0;
				}
				// o1 < o2   返回的是  -1 
				
				if (o1.getAge() < o2.getAge()) {
					return -1;
				}
				// o1 > o2 相等  返回的是  1 
				return 1;
			}
		});

		treeSet.add(new Gril(28, 80, "baby"));
		treeSet.add(new Gril(22, 70, "关晓彤"));
		treeSet.add(new Gril(38, 85, "高圆圆"));
		treeSet.add(new Gril(44, 90, "陈慧琳"));

		for (Gril gril : treeSet) {
			System.out.println(gril);
		}
		
	}
}
