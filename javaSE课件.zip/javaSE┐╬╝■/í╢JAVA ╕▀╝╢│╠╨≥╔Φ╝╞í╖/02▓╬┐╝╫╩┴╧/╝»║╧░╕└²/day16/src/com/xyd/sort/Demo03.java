/**
 * 
 */
package com.xyd.sort;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

/**
 * @author scott
 * @date 2017年12月20日上午10:19:12
 * @version 
 * @description  实现comparable 接口 可以 用 treemap 的键排序 
 */
public class Demo03 {
	
	public static void main(String[] args) {
		
		TreeMap<Sister, String> treemap = new TreeMap<>();
		
		treemap.put(new Sister(44, 70, "黄蓉"), "xyd");
		treemap.put(new Sister(22, 45, "如花"), "xyd");
		treemap.put(new Sister(22, 80, "王小米"), "xyd");
		treemap.put(new Sister(33, 75, "周芷若"), "xyd");
		
		Set<Sister> keySet = treemap.keySet();
		
		for (Sister sister : keySet) {
			System.out.println(sister);
		}
		
	}
	
}
