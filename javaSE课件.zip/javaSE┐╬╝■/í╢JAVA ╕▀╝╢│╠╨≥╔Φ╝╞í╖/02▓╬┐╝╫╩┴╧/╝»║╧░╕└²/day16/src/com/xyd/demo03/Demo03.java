/**
 * 
 */
package com.xyd.demo03;

import java.util.ArrayList;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月19日上午11:16:54
 * @version
 * @description
 */
public class Demo03 {

	public <T> void print(List<T> list) {

		for (int i = 0; i < list.size(); i++) {

			T t = list.get(i);
			System.out.println(t);
		}
	}
	public <T> T print1(List<T> list) {
		
		return list.get(0);
	}
	
	public <T> T print2(List<T> list) {
		
		return list.get(0);
	}
	
	//泛型可以变参数
	
	public <T> void print03(T ... arr){
		
		
	}
	

	public static void main(String[] args) {

		Demo03 demo03 = new Demo03();
		List<String> list = new ArrayList<>();
		list.add("aa");
		list.add("bb");
		list.add("cc");
		
		demo03.print(list);
		
		List<Person<String>> list1 = new ArrayList<>();
		
		//The constructor Person<String>(String, String) is undefined  构造器没有定义
		list1.add(new Person<String>("100","tom"));
	    String s1 = demo03.print1(list);
	    
	    System.out.println(s1);
	    
	    Person<String> p1 = demo03.print1(list1);
	    
	   //com.xyd.demo03.Person@7852e922  类名 + @ + hashCode的 16进制
	   
	    System.out.println(p1);

	}
}
