/**
 * 
 */
package com.xyd.sort;

import java.util.Comparator;

/**
 * @author scott
 * @date 2017年12月20日上午10:33:23
 * @version 
 * @description  实现 Gril 比较器  自己写比较规则
 *               一定要实现  比较器接口(comparator)
 * 
 */
public class GrilComparator implements Comparator<Gril>{

	@Override
	public int compare(Gril o1, Gril o2) {
		
		// o1 = o2 相等  返回的是  0 
		if (o1.getAge() == o2.getAge()) {
			return 0;
		}
		// o1 < o2   返回的是  -1 
		
		if (o1.getAge() < o2.getAge()) {
			return -1;
		}
		// o1 > o2 相等  返回的是  1   
		return 1;
	}

}
