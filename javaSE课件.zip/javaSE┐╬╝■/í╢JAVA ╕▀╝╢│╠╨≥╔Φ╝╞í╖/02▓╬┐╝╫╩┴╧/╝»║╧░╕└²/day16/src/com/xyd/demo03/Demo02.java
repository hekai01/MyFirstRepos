/**
 * 
 */
package com.xyd.demo03;

import java.util.ArrayList;
import java.util.List;

import org.omg.CORBA.OBJ_ADAPTER;

/**
 * @author scott
 * @date 2017年12月19日上午10:53:29
 * @version 
 * @description 通配符简单介绍
 */
public class Demo02 {

	public static void main(String[] args) {
		
		// Number  是  Integer 的 父类  
//		List<Number> list = new ArrayList<Integer>();
//		List<Object> list1 = new ArrayList<Integer>();
		
		// 通配符  ? 占个位置 不知道是什么类型  你给什么类就是什么类    和上限使用
		List<?> list2 = new ArrayList<Integer>();
		
		//不能添加东西  只能添加  null
//		list2.add(object);
		List<?> list3 = new ArrayList<Double>();
		
		
	}
}
