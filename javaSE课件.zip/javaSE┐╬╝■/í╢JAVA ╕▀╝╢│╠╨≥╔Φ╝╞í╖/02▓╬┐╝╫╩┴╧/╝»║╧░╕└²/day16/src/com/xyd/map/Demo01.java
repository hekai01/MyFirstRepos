/**
 * 
 */
package com.xyd.map;

import java.util.HashMap;
import java.util.Map;

/**
 * @author scott
 * @date 2017年12月19日下午3:53:25
 * @version 
 * @description  Map 的一些方法 
 */
public class Demo01 {

	public static void main(String[] args) {
		
		//创建Map的子类
		
		Map<String, Integer> map = new HashMap<>();
		
		//添加  
		map.put("aa", 11);
		map.put("bb", 22);
//		map.put("cc", 33);
		map.put("cc", 44); //如果 key 重复了  后面 的覆盖前面的   如果key 不存在 返回是 null
		
		//通过  可以  移除
		map.remove("aa");
		
		// 是否包含
		boolean containsKey = map.containsKey("cc");
		boolean containsValue = map.containsValue(44);
		System.out.println(containsValue);
		
		//长度
		System.out.println(map.size());
		
		//通过k 获取 value
		Integer integer = map.get("aa");
		System.out.println(integer);
		
		
	}
}
