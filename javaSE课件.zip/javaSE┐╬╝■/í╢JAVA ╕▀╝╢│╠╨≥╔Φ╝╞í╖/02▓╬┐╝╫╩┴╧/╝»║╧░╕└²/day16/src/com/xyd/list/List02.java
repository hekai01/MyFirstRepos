/**
 * 
 */
package com.xyd.list;

import java.awt.AlphaComposite;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

/**
 * @author scott
 * @date 2017年12月18日下午2:34:35
 * @version
 * @description ArrayList 的遍历
 * 
 *              1. 通过 迭代器 来遍历 1.获取 迭代器 2.判断是否有下一个 3.同过while 迭代器的 next 获取 对应的下标的值
 *              打印
 * 
 */
public class List02 {

	public static void main(String[] args) {

		List list = new ArrayList<>();

		list.add("aa");
		list.add(12);
		list.add(3.4f);
		list.add("cc");

		// test01(list);

		// test02(list);
//		test03(list);
		test04(list);

	}

	/**
	 * 通过ListIterator
	 */
	private static void test04(List list) {
		
		//获取迭代器    都是调用  Iterator 方法
		ListIterator listIterator = list.listIterator();
		//循环判断 是否有下一个
		while (listIterator.hasNext()) {
			
			//返回 下一个 的对象
			Object obj = listIterator.next();
			System.out.println(obj);
		}
	}

	/**
	 * 通过for 来遍历 get(index) 循环来操作 循环次数 i < list.size();
	 */
	private static void test03(List list) {

		for (int i = 0; i < list.size(); i++) {

			Object obj = list.get(i);
			System.out.println(obj);

		}

	}

	/**
	 * foreach 来遍历
	 * 
	 * for(数据类型 变量 :(数组或者集合)){ }
	 */
	private static void test02(List list) {

		for (Object obj : list) {

			System.out.println(obj);
		}

	}

	/**
	 * 通过迭代器 来遍历
	 */
	private static void test01(List list) {

		// 获取迭代器
		Iterator iter = list.iterator();

		// iter.hasNext() 是否 有下一个
		while (iter.hasNext()) {

			// 通过 next 来获取 对应的值
			Object next = iter.next();

			System.out.println(next);
		}
	}
}
