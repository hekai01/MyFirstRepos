/**
 * 
 */
package com.xyd.sort;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月20日上午10:28:34
 * @version 
 * @description 通过比较器接口来进行排序  Comparator 排序
 */
public class Demo05 {

	public static void main(String[] args) {
		
		List<Gril> list = new ArrayList<>();
		
		list.add(new Gril(28, 80, "baby"));
		list.add(new Gril(22, 70, "关晓彤"));
		list.add(new Gril(38, 85, "高圆圆"));
		list.add(new Gril(44, 90, "陈慧琳"));
		
		//Collections.sort(list,comparator)

		//Comparator<? super T> c 要 comparator 的 接口是实现类 (比较器 )
		
		//外部类 比较器的写法
//		GrilComparator grilComparator = new GrilComparator();
//		Collections.sort(list, grilComparator);
		//匿名内部类的写法
		Collections.sort(list, new Comparator<Gril>() {
			
			@Override
			public int compare(Gril o1, Gril o2) {
				// o1 = o2 相等  返回的是  0 
				if (o1.getAge() == o2.getAge()) {
					return 0;
				}
				// o1 < o2   返回的是  -1 
				
				if (o1.getAge() < o2.getAge()) {
					return -1;
				}
				// o1 > o2 相等  返回的是  1 
				return 1;
			}
		});
		
		for (Gril gril : list) {
			System.out.println(gril);
		}
		
	}
	
}
