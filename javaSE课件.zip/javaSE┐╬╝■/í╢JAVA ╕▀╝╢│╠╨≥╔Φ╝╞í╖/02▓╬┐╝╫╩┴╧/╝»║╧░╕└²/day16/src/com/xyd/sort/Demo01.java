/**
 * 
 */
package com.xyd.sort;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Random;

/**
 * @author scott
 * @date 2017年12月20日上午9:30:09
 * @version
 * @description 系统类 实现了 Comparable 接口可以排序(自然排序)
 */
public class Demo01 {

	public static void main(String[] args) {

		// intSort();

		// dateSort();

		strSort();

	}

	private static void strSort() {
		List<String> list = new ArrayList<>();

		list.add("aa");
		list.add("abc");
		list.add("aab");

		// 排序
		Collections.sort(list);

		for (String str : list) {
			System.out.println(str);
		}
	}

	/**
	 * 时间的排序
	 */
	private static void dateSort() {
		List<Date> dateList = new ArrayList<>();
		Date date1 = new Date();
		Date date2 = new Date(System.currentTimeMillis() + 10000);
		Date date3 = new Date(System.currentTimeMillis() - 10000);
		dateList.add(date1);
		dateList.add(date2);
		dateList.add(date3);

		// 排序
		Collections.sort(dateList);

		for (Date date : dateList) {
			System.out.println(new SimpleDateFormat("mm:ss").format(date));
		}
	}

	/**
	 * integer的排序
	 */
	private static void intSort() {
		// Integer 类实现类这个方法 测试 integer 排序
		ArrayList<Integer> intList = new ArrayList<>();

		Random random = new Random();

		for (int i = 0; i < 5; i++) {

			// 随机 5 - 15
			int num = random.nextInt(11) + 5;
			intList.add(num);
		}
		System.out.println(intList);

		// 排序
		Collections.sort(intList);

		for (Integer integer : intList) {
			System.out.println(integer);
		}
	}
}
