/**
 * 
 */
package com.xyd.demo03;

import java.util.ArrayList;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月19日上午11:38:49
 * @version 
 * @description 
 */
public class Demo05 {


	    public static void main(String[] args) {
	        List<? super Apple> list = new ArrayList<>();
	        
	        //只能添加  apple 和apple的子类   返回类型 是  Object
	        list.add(new Apple());
	        list.add(new Apple1());// 添加 apple的子类
	        
//	        list.add(new Fruit()); //添加apple 的父类  报错 

	        //obj
	        Object apple = list.get(0);
	        
	    }
	
}
class Fruit{}
class Apple extends Fruit{}
class Apple1 extends Apple{}
class Orange extends Fruit{}
