package com.xyd.demo01;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class StuParseHandler extends DefaultHandler{

    StuLister lister;

    private int tag = 0;

    private boolean flag = false;


    @Override
    public void startDocument() throws SAXException {
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

        if (qName.equals("age")){
            flag = true;
            tag++;
        }

    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {

        if (tag == 1 && flag){
            String str = new String(ch,start,length);
            System.out.println(str);

        }

    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {

        flag = false;

    }

    @Override
    public void endDocument() throws SAXException {

    }
}
