package com.xyd.demo01;

public class HelloServlet {

    public void doget(){

        System.out.println(" hello doget");

    }
}
