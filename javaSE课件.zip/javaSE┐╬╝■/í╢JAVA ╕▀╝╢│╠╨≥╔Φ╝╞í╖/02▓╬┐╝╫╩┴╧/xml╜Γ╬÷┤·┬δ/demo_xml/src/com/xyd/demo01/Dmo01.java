package com.xyd.demo01;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.lang.reflect.Method;

public class Dmo01 {

    public static void main(String[] args) throws Exception {

        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        //获取解析器
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

        Document doc = documentBuilder.parse(new File("demo_xml/src/a.xml"));


        Node item = doc.getElementsByTagName("servlet-class").item(0);

        String textContent = item.getTextContent();

        Class<HelloServlet> aClass = (Class<HelloServlet>) Class.forName(textContent);

        HelloServlet helloServlet = aClass.newInstance();
        Method doget = aClass.getDeclaredMethod("doget");

        doget.invoke(helloServlet);

    }

}
