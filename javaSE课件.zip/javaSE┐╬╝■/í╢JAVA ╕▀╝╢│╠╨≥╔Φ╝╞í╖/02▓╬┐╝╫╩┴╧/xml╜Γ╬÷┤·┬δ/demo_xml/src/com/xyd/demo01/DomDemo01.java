package com.xyd.demo01;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;

/**
 * Dom 解析
 */
public class DomDemo01 {

    public static void main(String[] args) throws Exception {
//        read01();

//        read02();

//        read03();

        read04();

    }

    private static void read04() throws Exception {

        //获取解析工厂
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

        //获取解析器
        DocumentBuilder builder = documentBuilderFactory.newDocumentBuilder();

        //解析xml 返回doc
        Document doc = builder.parse(new File("demo_xml/src/ab.xml"));

        //获取root
        Element root = doc.getDocumentElement();

        //
        Element person = (Element) root.getElementsByTagName("person").item(1);

        Node aa = doc.getElementsByTagName("aa").item(0);

        person.removeChild(aa);

        //回写  创建 创建一个用来转换DOM对象的工厂对象

        TransformerFactory transformerFactory = TransformerFactory.newInstance();

        //创建转换器
        Transformer transformer = transformerFactory.newTransformer();

        //定义要转换的对象
        DOMSource xml = new DOMSource(doc);

        //你要回写到那个地方去
        StreamResult sr = new  StreamResult(new File("demo_xml/src/ab.xml"));

        //开始转换
        transformer.transform(xml,sr);

        System.out.println("删除完毕");
    }


    /**
     * 添加节点
     */
    private static void read03() throws Exception {

        //获取解析工厂类
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

        //实例化解析器
        DocumentBuilder documentBuilder = factory.newDocumentBuilder();

        //解析xml 返回doc文档
        Document doc = documentBuilder.parse(new File("demo_xml/src/ab.xml"));

        //获取doc的根节点
        Element root = doc.getDocumentElement();

        NodeList person = root.getElementsByTagName("person");

        Node item = person.item(1);

        Element aa = doc.createElement("aa");
        aa.setTextContent("我是添加的节点");

        item.appendChild(aa);

        //回写   创建一个用来转换DOM对象的工厂对象

        TransformerFactory factory1 = TransformerFactory.newInstance();

        //获取转换器对象
        Transformer transformer = factory1.newTransformer();

        //定义要转换的源对象
        DOMSource source = new DOMSource(doc);

        //定义要转换到的目标文件
        StreamResult sr = new StreamResult("demo_xml/src/ab.xml");
        //开始转换
        transformer.transform(source, sr);

        System.out.println("转换器操作...");


    }


    /**
     * dom解析
     */
    private static void read02() throws Exception {

        //需要解析工厂类
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();

        //实例化解析器
        DocumentBuilder docBuiler = docFactory.newDocumentBuilder();

        //解析xml 文档
        Document doc = docBuiler.parse(new File("demo_xml/src/ab.xml"));

        //拿到根节点
        Element root = doc.getDocumentElement();

        Node person = root.getElementsByTagName("person").item(0);

        NodeList childNodes = person.getChildNodes();

        for(int i = 0 ; i < childNodes.getLength() ; i++){

            Node item = childNodes.item(i);

            System.out.println(item.getNodeName() + item.getTextContent());

        }

    }

    /**
     * dom解析
     * @throws ParserConfigurationException
     * @throws SAXException
     * @throws IOException
     */
    private static void read01() throws ParserConfigurationException, SAXException, IOException {
        //1.实例化 工厂类
        DocumentBuilderFactory domfactory = DocumentBuilderFactory.newInstance();

        //2 实例化解析器
        DocumentBuilder builder = domfactory.newDocumentBuilder();

        //3.解析xml文档  返回document 对象
        Document doc = builder.parse(new File("demo_xml/src/ab.xml"));

        //获取根节点
        Element root = doc.getDocumentElement();

        //获取所有的子节点
        NodeList childNodes = root.getChildNodes();

        for(int i = 0;i < childNodes.getLength(); i++){

            Node node = childNodes.item(i);

            NodeList children= node.getChildNodes();

            for(int j = 0;j < children.getLength();j++){

                Node person = children.item(j);

                if(person.getNodeName().equals("age")){
                    System.out.println(person.getTextContent());
                }else if(person.getNodeName().equals("name")){
                    System.out.println(person.getTextContent());
                }else if(person.getNodeName().equals("phone")){
                    System.out.println(person.getTextContent());
                }

            }
        }
    }
}
