package com.xyd.demo01;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import java.io.File;

/**
 * SAX 解析
 */
public class SaxDemo01 {

    public static void main(String[] args) throws Exception{

        //1.穿件  Sax解析器
        SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();

        //2. 通过过工厂创建 SAx解析器
        SAXParser parser = saxParserFactory.newSAXParser();

        //3 使用解析器开始解析
        PersonHandler personHandler = new PersonHandler();
        parser.parse(new File("demo_xml/src/ab.xml"),personHandler);

    }


    static class PersonHandler extends DefaultHandler{

        int tag = 0;

        @Override
        public void startDocument() throws SAXException {
        }

        @Override
        public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {

            if (qName.equals("age")){
                tag = 1;
            }else if(qName.equals("name")){
                tag = 2;
            }
        }

        @Override
        public void characters(char[] ch, int start, int length) throws SAXException {
            if (tag == 2){
                System.out.println(new String(ch,start,length));
            }

        }

        @Override
        public void endElement(String uri, String localName, String qName) throws SAXException {

            tag =0;

        }

        @Override
        public void endDocument() throws SAXException {

        }
    }


}
