package com.xyd.demo01;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;

/**
 * dom4j 解析
 */
public class Dom4j {

    public static void main(String[] args) throws Exception {

        //read01();

//        read02();

//        read03();

//         read04();

        read05();

    }

    /**
     * 修改节点
     */
    private static void read05() throws Exception {

        //获取解析器
        SAXReader reader = new SAXReader();

        //解析xml
        Document doc = reader.read("demo_xml/src/ab.xml");

        //获取根节点
        Element rootElement = doc.getRootElement();

        //获取person
        Element person = rootElement.elements().get(0);
        Element name = person.element("name");
        name.setText("马云");

        //回写
        OutputFormat format = OutputFormat.createCompactFormat();
        format.setEncoding("utf-8");

        //回写类
        XMLWriter writer = new XMLWriter(new FileOutputStream("demo_xml/src/ab.xml"),format);

        writer.write(doc);

        writer.close();

    }

    /**
     * 删除节点
     */
    private static void read04() throws Exception {

        //获取解析器
        SAXReader saxReader = new SAXReader();

        //解析xml
        Document doc = saxReader.read(new File("demo_xml/src/ab.xml"));

        //获取root
        Element root = doc.getRootElement();

//        找到第2个人的节点

        Element person = root.elements().get(1);
        //找到节点 cc
        Element cc = person.element("cc");
        person.remove(cc);

        //回写
        OutputFormat format = OutputFormat.createCompactFormat();
        XMLWriter writer = new XMLWriter(new FileOutputStream("demo_xml/src/ab.xml"),format);

        writer.write(doc);

        writer.close();

        System.out.println("删除完毕");

    }

    /**
     * 在第二个人后面  添加子节点
     */
    private static void read03() throws Exception {

        //获取 解析器
        SAXReader saxReader = new SAXReader();

        //解析xml 返回doc
        Document doc = saxReader.read(new File("demo_xml/src/ab.xml"));

        //获取根节点
        Element rootElement = doc.getRootElement();

        //获取第二个人的节点
        Element person = rootElement.elements().get(1);

        //直接添加子节点
        person.addElement("cc").setText("小米");

        //回写操作

        //漂亮格式
        OutputFormat format = OutputFormat.createCompactFormat();

        //设置编码
        format.setEncoding("utf-8");

        //回写类
        XMLWriter writer = new XMLWriter(new FileOutputStream("demo_xml/src/ab.xml"),format);
        writer.write(doc);
        //关闭资源
        writer.close();


    }

    /**
     * 获取 第第二个人的 文件内容
     */
    private static void read02() throws DocumentException {

        //获取解析器

        SAXReader saxReader = new SAXReader();

        //解析xml 返回document
        Document doc = saxReader.read(new File("demo_xml/src/ab.xml"));

        //获取根节点
        Element root = doc.getRootElement();

        //获取第2个人
        Element person = root.elements().get(1);

        //获取信息
        Element name = person.element("name");

        System.out.println("name :" + name.getText());


    }


    /**
     * 解析xml
     * @throws DocumentException
     */
    private static void read01() throws DocumentException {
        //创建xml的阅读器

        SAXReader saxReader = new SAXReader();

        //解析xml文件
        Document doc = saxReader.read(new File("demo_xml/src/ab.xml"));

        //拿到根节点
        Element rootElement = doc.getRootElement();


        List<Element> elements = rootElement.elements();

        for(int i = 0 ; i < elements.size();i++){

            //获取节点
            Element e = elements.get(i);

            Element age = e.element("age");
            Element name = e.element("name");
            System.out.println(age.getText());
            System.out.println(name.getText());
        }
    }
}
