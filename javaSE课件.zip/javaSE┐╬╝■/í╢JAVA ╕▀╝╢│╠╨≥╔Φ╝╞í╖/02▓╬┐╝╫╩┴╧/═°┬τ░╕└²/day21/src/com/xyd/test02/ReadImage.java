/**
 * 
 */
package com.xyd.test02;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.Socket;

import com.xyd.test01.IOUtils;

/**
 * @author scott
 * @date 2017年12月26日上午10:46:29
 * @version
 * @description
 */
public class ReadImage implements Runnable {

	// 写图片 写src/maria.jpg

	private BufferedOutputStream bos = null;

	// 读取 服务的图片
	private BufferedInputStream bis = null;

	public ReadImage(Socket socket) {
		try {
			bis = new BufferedInputStream(socket.getInputStream());
			bos = new BufferedOutputStream(new FileOutputStream(new File("src/maria.jpg")));
					
					
		} catch (IOException e) {
			e.printStackTrace();
			IOUtils.close(bis, socket);
		}

	}

	@Override
	public void run() {

		readImage();
		
	}

	private void readImage() {
		
		byte [] buffer = new byte[1024];
		int len = 0;
		
		try {
			while ((len = bis.read(buffer)) != -1) {
				
				bos.write(buffer, 0, len);
				bos.flush();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			IOUtils.close(bos,bis);
			System.out.println("传输完毕...");
		}
		
	}

}
