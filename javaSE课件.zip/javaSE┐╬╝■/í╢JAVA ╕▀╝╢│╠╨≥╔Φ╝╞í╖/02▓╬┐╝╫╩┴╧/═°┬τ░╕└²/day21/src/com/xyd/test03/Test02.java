/**
 * 
 */
package com.xyd.test03;

/**
 * @author scott
 * @date 2017年12月26日下午2:31:39
 * @version
 * @description 用枚举 标记颜色
 */
public class Test02 {

	public static void main(String[] args) {

//		isColor(Color.RED);

		swithColor(Color.RED);

	}

	/**
	 * 枚举用于switch
	 */
	private static void swithColor(Color red) {

		switch (red) {
		case RED:
			System.out.println("红色");
			break;
		case YELLOY:
			System.out.println("黄色");
			break;

		}

	}

	/**
	 * 枚举用于判断
	 */
	private static void isColor(Color red) {

		if (red == Color.RED) {

			System.out.println("红色");

		}
		if (red == Color.YELLOY) {

			System.out.println("黄色");

		}
	}
}
