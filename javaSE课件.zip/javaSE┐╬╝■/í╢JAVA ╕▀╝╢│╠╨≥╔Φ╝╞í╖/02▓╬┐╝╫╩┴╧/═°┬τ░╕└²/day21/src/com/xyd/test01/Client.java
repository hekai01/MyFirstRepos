/**
 * 
 */
package com.xyd.test01;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

/**
 * @author scott
 * @date 2017年12月26日上午9:39:49
 * @version
 * @description 测试 socket 的客户端 操作步骤: 
 *           1.建立socket
 *           2.获取io流
 *           3.操作 
 *           4.关闭
 * 
 */
public class Client {

	public static void main(String[] args) {

		//1. ip 建立联系 （Socket）
		Socket socket = null;
		InputStream is = null;
		DataInputStream dis = null;
		try {
			 socket = new Socket("127.0.0.1", 8888);

			// 通过 socket 获取 流
			 is = socket.getInputStream();

			// 操作
			 dis = new DataInputStream(is);

			String msg = dis.readUTF();
			System.out.println(msg);
			//关闭资源
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			IOUtils.close(dis,is,socket);
		}

	}
}
