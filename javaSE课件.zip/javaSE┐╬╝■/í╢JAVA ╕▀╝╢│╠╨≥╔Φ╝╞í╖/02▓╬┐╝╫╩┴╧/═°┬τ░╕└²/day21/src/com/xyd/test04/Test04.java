/**
 * 
 */
package com.xyd.test04;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 * @author scott
 * @date 2017年12月26日下午4:16:21
 * @version 
 * @description  String - > int   有错误   写到文件中保存
 */
public class Test04 {

	public static void main(String[] args) {
		
		writeLog("src/log.txt");
		
	}

	/**
	 * 写日志
	 * 
	 * 思路:
	 *   1.获取键盘输入的 字符串  转成  int
	 *   
	 *   2.捕获异常
	 *   
	 *   3.组装 err信息
	 *   
	 *   4.io的操作
	 * 
	 */
	private static void writeLog(String path) {
		
		System.out.println("请输入数字?");
		Scanner sc = new Scanner(System.in);
		
		String msg = sc.next();
		
		try {
			int parseInt = Integer.parseInt(msg);
		} catch (Exception e) {
			
			String time = getTime();
			
			//组装了报错信息
			String err = "err:"+time+" Scanner输入类型错误，要求输入int，却输入了"+ msg;

			//写到 文件中
			write(path,err);
			
		}
		
		
	}

	/**
	 * 报错信息写到  log.txt 中
	 */
	private static void write(String path,String msg) {

		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(new File(path),true));
			bw.write(msg+"\r\n");
			
			bw.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if (bw != null) {
				try {
					bw.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println("报错了 查看日志");
	}

	/**
	 * 获取系统时间 格式化
	 */
	private static String getTime() {
		
		return new SimpleDateFormat("yyyy年MM月dd日 HH:mm:ss").format(new Date());
	}
}
