/**
 * 
 */
package com.xyd.test03;

/**
 * @author scott
 * @date 2017年12月26日下午2:24:37
 * @version 
 * @description 
 */
public class Contants {

//	Calendar c;
	/**
	 * 红色
	 */
	public static final int RED = 1;
	/**
	 * 黄色
	 */
	public static final int YELLOW = 2;
	/**
	 * 绿色
	 */
	public static final int GREEN = 3;
	
	/**
	 * 白色
	 */
	public static final int WHITE= 4;
}
