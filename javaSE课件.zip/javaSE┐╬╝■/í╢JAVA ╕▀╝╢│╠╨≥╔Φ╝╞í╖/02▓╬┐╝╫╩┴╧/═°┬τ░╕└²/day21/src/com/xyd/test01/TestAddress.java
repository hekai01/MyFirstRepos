/**
 * 
 */
package com.xyd.test01;

import java.net.InetAddress;

/**
 * @author scott
 * @date 2017年12月26日上午9:23:18
 * @version 
 * @description  测试 InetAddress   这个类是对 ip 进行了封装
 */
public class TestAddress {

	public static void main(String[] args) throws Exception {
		
		//通过静态方法  返回一个 inetAddress
		InetAddress localHost = InetAddress.getLocalHost();
		
		//获取 InetAddress对象的主机名。
		String hostName = localHost.getHostName();
		System.out.println("hostName : " +hostName);
		
		// 获取本地ip地址
		System.out.println(localHost.getHostAddress());
		
		// 获取主机名为baidu的ip地址  使用DNS查找指定主机名或域名为hostname的IP地址，
		InetAddress baidu = InetAddress.getByName("www.baidu.com");
		System.out.println("baidu:"+baidu.getHostAddress());
		
		//获取  本机  的 ip 
		InetAddress a = InetAddress.getByName("localhost");
		System.out.println("sina:"+a.getHostAddress());
	}
}
