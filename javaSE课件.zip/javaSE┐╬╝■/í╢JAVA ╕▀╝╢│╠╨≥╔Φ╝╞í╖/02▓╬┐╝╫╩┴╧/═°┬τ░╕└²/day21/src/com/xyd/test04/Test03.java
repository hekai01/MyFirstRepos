/**
 * 
 */
package com.xyd.test04;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月26日下午4:04:13
 * @version
 * @description
 * 
 * 				思路: 1.用io流读取 文本 2.字符串操作 3.字符串封装成对象 添加到 List中
 */
public class Test03 {

	public static void main(String[] args) {

		List<WorldCup> list = read();
		
		for (WorldCup worldCup : list) {
			System.out.println(worldCup);
        }
		
	}

	private static List<WorldCup> read() {
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader("src/a.txt"));

			String msg = "";

			List<WorldCup> list = new ArrayList<>();

			while ((msg = br.readLine()) != null) {

				// 2002,韩国和日本,巴西
				String[] values = msg.split(",");
				WorldCup worldCup = new WorldCup(Integer.valueOf(values[0]), values[1], values[2]);
				list.add(worldCup);
			}
			
			return list;
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;

	}
}
