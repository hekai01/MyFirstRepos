/**
 * 
 */
package com.xyd.test02;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 * @author scott
 * @date 2017年12月26日上午10:46:15
 * @version 
 * @description
 */
public class Client {

	public static void main(String[] args) throws UnknownHostException, IOException {
		
		//建立socket 连接
		Socket socket = new Socket("127.0.0.1", 9999);
		
		new Thread(new ReadImage(socket)).start();
		
	}
}
