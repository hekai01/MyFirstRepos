/**
 * 
 */
package com.xyd.test03;

/**
 * @author scott
 * @date 2017年12月26日下午2:31:04
 * @version 
 * @description 
 */
public enum Color {

	RED,YELLOY,WHITE
	
}
