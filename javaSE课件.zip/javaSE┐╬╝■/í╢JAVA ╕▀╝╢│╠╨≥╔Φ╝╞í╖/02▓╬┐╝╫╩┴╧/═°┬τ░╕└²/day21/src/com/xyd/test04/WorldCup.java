/**
 * 
 */
package com.xyd.test04;

/**
 * @author scott
 * @date 2017年12月26日下午4:08:36
 * @version 
 * @description 
 */
public class WorldCup {

	private int year;
	
	private String country;
	
	private String winner;

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getWinner() {
		return winner;
	}

	public void setWinner(String winner) {
		this.winner = winner;
	}

	public WorldCup(int year, String country, String winner) {
		this.year = year;
		this.country = country;
		this.winner = winner;
	}
	
	public WorldCup() {
	}

	@Override
	public String toString() {
		return "WorldCup [year=" + year + ", country=" + country + ", winner=" + winner + "]";
	}
	
	
	
}
