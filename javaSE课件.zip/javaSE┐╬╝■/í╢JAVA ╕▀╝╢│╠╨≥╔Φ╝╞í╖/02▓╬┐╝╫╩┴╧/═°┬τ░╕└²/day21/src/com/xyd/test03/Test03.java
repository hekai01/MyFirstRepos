/**
 * 
 */
package com.xyd.test03;

/**
 * @author scott
 * @date 2017年12月26日下午2:40:50
 * @version 
 * @description 
 */
public class Test03 {

	public static void main(String[] args) {
		
		System.out.println(ColorNum.BLUE.getColor() +" " +ColorNum.BLUE.getNum());
		
		ColorNum[] values = ColorNum.values();
		
		for (ColorNum colorNum : values) {
			System.out.println(colorNum.getColor() + " " + colorNum.getNum());
		}
		
	}
}
