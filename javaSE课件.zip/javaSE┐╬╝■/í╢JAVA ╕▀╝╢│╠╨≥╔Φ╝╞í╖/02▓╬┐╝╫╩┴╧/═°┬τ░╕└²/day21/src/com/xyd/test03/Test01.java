/**
 * 
 */
package com.xyd.test03;

import java.time.temporal.WeekFields;

/**
 * @author scott
 * @date 2017年12月26日下午2:24:06
 * @version 
 * @description  测试 java 的使用
 */
public class Test01 {

	public static void main(String[] args) {
		
//		WeekFields   用枚举  
//		Calander     用的是常量 
		
		isColor(45);
	}

	private static void isColor(int red) {

		if (red == Contants.RED) {
			System.out.println("红色");
		}
		
		if (red == Contants.YELLOW) {
			System.out.println("黄色");
		}
		
		if (red == Contants.WHITE) {
			System.out.println("白色");
		}
	}
}
