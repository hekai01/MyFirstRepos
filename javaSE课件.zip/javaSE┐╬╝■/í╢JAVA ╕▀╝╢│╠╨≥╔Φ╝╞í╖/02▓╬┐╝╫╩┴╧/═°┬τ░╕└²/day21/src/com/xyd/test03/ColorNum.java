/**
 * 
 */
package com.xyd.test03;

/**
 * @author scott
 * @date 2017年12月26日下午2:37:31
 * @version 
 * @description 
 */
public enum ColorNum {
	
    RED("红色",1),YELLOW("黄色",2),BLUE("蓝色",3);
	
	private ColorNum(String color, int num) {
		this.color = color;
		this.num = num;
	}
	
	private String color;
	private int num;
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	
	
}
