/**
 * 
 */
package com.xyd.time;

import java.util.Date;

/**
 * @author scott
 * @date 2017年12月14日下午3:20:10
 * @version 
 * @description  测试 date 类
 */
public class TestDate01 {

	public static void main(String[] args) {
		
		//构造 Date()创建
		Date date = new Date();  // 空 会调用 有参构造器(系统时间)
		//通过 long 值表示 时间  1513236144198 
		//通过 date的方法 getTime() 拿到 对应 的  long
		System.out.println(date.getTime());
		
		//System.currentTimeMillis()  拿到系统的时间 
		System.out.println(System.currentTimeMillis());
	
		System.out.println(date.toString());
		
		// 过时方法 不建议 大家使用
		System.out.println(date.getYear() + 1900);
		
		// 0 是 一月    11  是 12 月
		System.out.println(date.getMonth());
		
	}
}
