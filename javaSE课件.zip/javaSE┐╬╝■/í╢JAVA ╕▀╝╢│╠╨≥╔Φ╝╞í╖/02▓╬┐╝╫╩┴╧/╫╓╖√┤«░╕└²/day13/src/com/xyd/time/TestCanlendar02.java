/**
 * 
 */
package com.xyd.time;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

/**
 * @author scott
 * @date 2017年12月14日下午3:49:33
 * @version 
 * @description calendar 类中的方法
 */
public class TestCanlendar02 {

	public static void main(String[] args) {
		
		//这个是 calendar是 子类   GregorianCalendar
		Calendar calendar  = new GregorianCalendar();
		
		System.out.println("Set设置时间");
		//set 设置 时间 (Filed(对应的属性),value(值))
		calendar.set(Calendar.YEAR, 2020);
		calendar.set(Calendar.DAY_OF_MONTH, 20);
	
		//set 年月日 时分秒
		calendar.set(2100, Calendar.MAY, 23, 12, 45, 23);
		
		//set 可以设置  date
		calendar.setTime(new Date(System.currentTimeMillis() - 128940328409L));
		
		//set  可以 设置 long 值
		calendar.setTimeInMillis(1432255434645L);
		
		print(calendar, Calendar.YEAR,Calendar.DAY_OF_MONTH,Calendar.HOUR_OF_DAY);

		System.out.println("*********get方法***********");
		
		//返回date
		Date time = calendar.getTime();
		calendar.setTime(new Date());
		
		//获取 月份 最大天数
		int  day = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		int  day1 = calendar.getActualMaximum(Calendar.DATE);
		System.out.println(day);
		System.out.println(day1);
		
		//相加   属性  
		calendar.add(Calendar.YEAR, -10);
		
		print(calendar, Calendar.YEAR);
		
	}
	
	public static void print(Calendar calendar,int ... arrs) {
		
		for (int i = 0; i < arrs.length; i++) {
			System.out.println(calendar.get(arrs[i]));
		}
	}
}
