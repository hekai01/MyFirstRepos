/**
 * 
 */
package com.xyd.time;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author scott
 * @date 2017年12月14日下午3:31:12
 * @version 
 * @description  date 格式化
 * 
 *       Date - > String
 *       
 *       String - >Date     
 */
public class TestDate02 {
	
	public static final long MIN = 60 * 1000L; 

	public static void main(String[] args) throws ParseException {
		
		// date - String
		Date date = new Date();
		//simpleDateFormat  
		/**
		 * yyyy 年
		 * 
		 * MM   月
		 * 
		 * dd   天
		 * 
		 * HH   24 小时
		 * 
		 * mm   分
		 * 
		 * ss   秒
		 *    
		 * 
		 */
		//时间格式化 的创建
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy年MM月dd日HH时mm分ss秒");
		//date 转成 对用的字符串
		String format = sdf.format(date);
		System.out.println(format);
		
		//字符串转成时间
		String time = "2017-2-28";
		
		//时间格式化类 
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		Date date2 = simpleDateFormat.parse(time);
		
		long afterT = date2.getTime() + 2 * (MIN * 60 * 24);
		
		System.out.println(DateUitls.long2Str(afterT));
		
	}
}
