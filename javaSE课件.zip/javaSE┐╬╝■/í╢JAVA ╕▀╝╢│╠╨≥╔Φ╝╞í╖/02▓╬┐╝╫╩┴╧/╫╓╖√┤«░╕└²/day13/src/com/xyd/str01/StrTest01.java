/**
 * 
 */
package com.xyd.str01;

/**
 * @author scott
 * @date 2017年12月14日上午9:25:40
 * @version 
 * @description 字符比较的一些方法 
 */
public class StrTest01 {

	public static void main(String[] args) {
		
		String str = "helloJava";
		
		//判断是否以什么开始
		boolean startsWith = str.startsWith("laosong");
		boolean endsWith = str.endsWith("Java");
		
		System.out.println(endsWith ? "是": "不是");
		
		//统计以什么开始
		/**
		 * 思路:
		 *   1.拿到 每个字符串  
		 *   2.判断每个字符是否以st开头
		 *   3.统计
		 */
		String strings[]= {"string","starting","strong","street", "stir","studeng","soft","sting"};

		int count = countStr(strings,"st");
		System.out.println(count);
	}

	/**
	 * 通过  数组中的 字符串 以str 开始
	 * 
	 * 思路:
	 *   1.拿到 每个字符串  
	 *   2.判断每个字符是否以st开头
	 *   3.统计
	 */
	private static int countStr(String[] strs, String str) {
		int count = 0;
		for (int i = 0; i < strs.length; i++) {
			
			if (strs[i].startsWith(str)) {
				count++;
			}
		}
		return count;
	}
}
