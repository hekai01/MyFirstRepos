/**
 * 
 */
package com.xyd.str01;

/**
 * @author scott
 * @date 2017年12月14日上午9:35:41
 * @version 
 * @description  字符串查找
 * https://ss0.bdstatic.com.70cFvHSh_Q1YnxGkpoWK1HF6hhy.it/u=757524083.1712758837&fm=27&gp=0.jpg
 * 
 * 思路:
 *   1.找到最后一个点 的位置  lastIndexOf();
 *   2.subString();
 * 
 */
public class StrTest02 {

	public static void main(String[] args) {
		
		String str = "helloWorld";
		
		String path = "https://ss0.bdstatic.com.70cFvHSh_Q1YnxGkpoWK1HF6hhy.it/u=757524083.1712758837&fm=27&gp=0.jpg";

		// str 在字符串中的第一次出现的下标的位置  如果没有返回 - 1
		int indexOf = str.indexOf("android");
		System.out.println(indexOf);
		
		//返回 str 在字符串中的最后一次出现的下标的位置，如果不存在，返回-1
		int lastIndexOf = str.lastIndexOf("l");
		System.out.println(lastIndexOf);

		
		/**
		 *  找到点的位置
		 *  index = path.lastIndexOf(".")
		 *  
		 *  path.substring(index)
		 *  
		 */
		String substring = path.substring(path.lastIndexOf("."));
		
		System.out.println(substring);
		
		//字符串的 index 下标位置的字符
		
		char charAt = str.charAt(4);
		System.out.println(charAt);
		/**
		 * 通过 一个字符中  有 字符的个数
		 * 
		 * 1.拿到字符中的 每个字符
		 * 
		 * 2.判断 统计
		 */

		String msg = "hfakhd42343fkahdlfkjal432543rqewrlkjlkj3rewrlkjljkrqewlrjqwlek";
		
		//思路 通过  判断asc值
		
		int count = countChar(str);
		System.out.println(count);
		
		//是否包含字符串
		//"hello日本 " 判断是否有日本 有我替换成中国
		boolean contains = str.contains("World");
		
		String result = replaceStr("hello日本 ","日本","中国");
		
		System.out.println(result);
		
		System.out.println(contains ? "包含" : "不包含");
	}

	/**
	 * 字符串中  src 替换成    dest
	 * 
	 */
	private static String replaceStr(String str, String src, String dest) {
		
		if (str.contains(src)) { //判断是否 包含
			     //str 中  src 替换成  dest
			return str.replace(src, dest);
		}
		
		return null;
	}

	/**
	 * 统计字符串中  字符c 的个数
	 */
	private static int countChar(String str) {
		
		int count = 0;
		for (int i = 0; i < str.length(); i++) {
			
			if (str.charAt(i) >= '0' &&str.charAt(i) <= '9' ) {
				count ++;
			}
			
		}
		return count;
	}
	
	
}
