/**
 * 
 */
package com.xyd.time;

import java.util.Calendar;

/**
 * @author scott
 * @date 2017年12月14日下午4:18:38
 * @version
 * @description
 * 
 */
public class TestDateForDayOfYear {

	public static void main(String[] args) {

		String date = "2017-12-14";

		System.out.println(Calendar.getInstance().get(Calendar.DAY_OF_YEAR));

		// for
		int year = 2017;
		int month = 12;
		int day = 14;

		// 1 , 3, 5 ,7 , 8 , 10 , 12 31
		// 4 , 6 ,9 , 11
		// 2 28
		int yearOfDay = 0;
		for (int i = 1; i < month; i++) {
			switch (i) {
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				yearOfDay += 31;
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				yearOfDay += 30;
				break;
			case 2:

				if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0)) { // 闰年 29
					yearOfDay += 29;
				} else {
					yearOfDay += 28;
				}
				break;
			}
		}
		System.out.println(yearOfDay + day);
		// date(2017-12-14) - date(2017-1-1) = long
		// 求天数
	}
}
