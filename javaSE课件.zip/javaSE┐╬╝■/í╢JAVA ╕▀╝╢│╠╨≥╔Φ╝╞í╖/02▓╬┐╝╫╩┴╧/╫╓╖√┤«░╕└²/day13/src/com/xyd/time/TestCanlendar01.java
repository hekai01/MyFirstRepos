/**
 * 
 */
package com.xyd.time;

import java.util.Calendar;
import java.util.GregorianCalendar;

/**
 * @author scott
 * @date 2017年12月14日下午3:49:33
 * @version 
 * @description calendar 类测试  获取 Calendar 这个  信息
 * 
 * //给你  个  日期 求出  这个是一年的 第多少天   2017-12-14
 * 
 */
public class TestCanlendar01 {

	public static void main(String[] args) {
		
		//calendar 类是 抽象类  不能直接new 
		Calendar c;
		//getInstance 来获取 实例
		c = Calendar.getInstance(); 
		//这个是 calendar是 子类   GregorianCalendar
		Calendar calendar  = new GregorianCalendar();
		
		//拿到 calendar 所有的信息
		
		//field  获取  calendar 对应的  时间信息
		
		// 获取年份
		int year = calendar.get(Calendar.YEAR);
		//月 0 - 11 之间  11 是12 月
		int month = calendar.get(Calendar.MONTH);
		int day_of_month = calendar.get(Calendar.DAY_OF_MONTH);
		
		//1 - 7  1 是星期天     7 星期六 
		int day_of_week = calendar.get(Calendar.DAY_OF_WEEK);
		
		//给你  个  日期 求出  这个是一年的 第多少天  
		int day_of_year = calendar.get(Calendar.DAY_OF_YEAR);
		
		System.out.println(year);
		System.out.println(month);
		System.out.println(day_of_month);
		System.out.println(day_of_week);
		System.out.println(day_of_year);
	}
}
