/**
 * 
 */
package com.xyd.str01;

/**
 * @author scott
 * @date 2017年12月14日上午10:39:12
 * @version 
 * @description 
 */
public class StringBuildTest01 {

	public static void main(String[] args) {
		
		StringBuilder sb = new  StringBuilder("helloworld");
		
		//append  追加
		// 链式编程  
//		sb.append("zzz").append(23).append(true);
//		System.out.println(sb);
//		
//		//反转
//		StringBuilder reverse = sb.reverse();
//		System.out.println(reverse);
//		
//		reverse(sb.toString());//dlrowolleh
		
		sb.insert(3, 24);
		System.out.println(sb);
		
		sb.delete(3, 5);
		System.out.println(sb);
	}

	//自己实现反转
	private static void reverse(String str) {
		
		String msg = "";
		for (int j = str.length() - 1; j >= 0; j--) {
			char charAt = str.charAt(j);
			msg +=charAt;
		}
		
		System.out.println(msg);
	}
}
