/**
 * 
 */
package com.xyd.str01;

/**
 * @author scott
 * @date 2017年12月14日下午2:49:45
 * @version 
 * @description 
 */
public class Test06 {

	public static void main(String[] args) {
		
		String str="123dsgfadsgjlafdjhladDWAdlfgjalDSFADSFDASnhsdaf!@$%@#45324rdsf";
	
		countCh(str);
	}
	
	/**
	 * 
	 * 思路:
	 *   1.转成字符:
	 *       1. charAt();           char
	 *       
	 *       2. toCharArray();      char[]
	 *   
	 *       3. split();            String[]
	 * 
	 *   2.匹配:
	 *       1.可以通过  字符匹配    a - z { ch >= 'a' && ch <= 'z'}
	 *       2.可以通过 asc码匹配 a - z   ch >=  97 && ch <=  122
	 *       3.可以通过正则表达式  a - z   ch.matches([a-z]) 匹配 数字:[0-9] 或者 \d
	 * 
	 */
	public static void countCh(String str) {
		
		int countNum = 0;
		int countCh = 0;
		String[] split = str.split("");
		
		for (String s : split) {
			
			if (s.matches("\\d")) {
				countNum ++;
			}

			if (s.matches("[a-z]")) {
				countCh++;
			}
			
		}
		System.out.println("0 - 9的个数:" + countNum);
		System.out.println("a - z的个数:" + countCh);
	}
}
