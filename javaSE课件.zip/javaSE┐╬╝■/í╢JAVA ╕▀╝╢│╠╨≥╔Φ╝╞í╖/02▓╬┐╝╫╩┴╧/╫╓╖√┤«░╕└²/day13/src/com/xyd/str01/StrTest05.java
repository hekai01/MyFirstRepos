/**
 * 
 */
package com.xyd.str01;

/**
 * @author scott
 * @date 2017年12月14日下午2:09:42
 * @version 
 * @description 
 */
public class StrTest05 {

	public static void main(String[] args) {
		
		System.out.println(CheckUtils.checkId("42112319800714721X"));
		
		System.out.println(CheckUtils.checkPhone("18566230139"));
		
		System.out.println(CheckUtils.checkEmail("xyd@163.com"));
		
		String str = "java12Php34C++";
		
		//字符串的替换
		String replaceAll = str.replaceAll("12", "\\$");
		
		//可以通过正则表达式 匹配替换  [a-z] 匹配小写字符
		String replaceAll2 = str.replaceAll("[a-z]", "O");
		
		// \d 匹配数组 替换
		String replaceAll3 = str.replaceAll("\\d", "O");
		// \D 匹配非数字  
		String replaceAll4 = str.replaceAll("\\D", "O");
		
		
		String msg = "  afd  afdaf dsaf a   ";
		
		//trim()  只能去掉 首尾的空格
		String trim = msg.trim();
		System.out.println(trim);
		
		//去掉所有的 空格
		String replaceAll5 = msg.replaceAll("\\s", "");
		System.out.println(replaceAll5);
		
		System.out.println(replaceAll);
		System.out.println(replaceAll2);
		System.out.println(replaceAll3);
		System.out.println(replaceAll4);
		
		
		//字符串的切割
		String str2= "ab : ce : ed : qq ";
		
		String[] split = str2.split(":");
		
		for (String string : split) {
			System.out.println(string.trim());
		}
		
		String str3 = "4343java143Php4432C++345";
		
		//切割   一个或者 多个  数字
		String[] split2 = str3.split("\\d{1,}");
		
		String s = "";
		for (String string : split2) {
			if (!string.isEmpty()) {
				System.out.println(string.trim());
			}
//			s+=string;
		}
		System.out.println(s);
		
		String s2 = "";
		if (s2 != null && s2.length() > 0) {
			System.out.println(s2.length());
		}
	}
}
