/**
 * 
 */
package com.xyd.str01;

import java.util.Arrays;

/**
 * @author scott
 * @date 2017年12月14日上午10:14:49
 * @version 
 * @description   String 与 char[] 的 转换
 */
public class StrTest03 {

	public static void main(String[] args) {
		
//		String valueOf = String.valueOf(23);
//		System.out.println(valueOf + 1);
		
		String str = "helloXiaoMi";
		//拷贝一份String中的所有字符。返回char[]
		//charAt();
		char[] charArray = str.toCharArray();
		System.out.println(Arrays.toString(charArray));
		
		
		int count = countStr(str,'l');
	
		System.out.println(count);
		
		//char 数组 转成字符串
		char [] chs = {'h','e','l','l','o'};
		
		String string = new String(chs);
		System.out.println(string);
		
		//chs 是char 数组       2 从那个地方发开始      3  长度 
		String string2 = new String(chs,2,3);
		
		System.out.println(string2);
		
	}

	private static int countStr(String str, char c) {
		
		int count = 0;
		char[] charArray = str.toCharArray();
		
		for (char d : charArray) {
			
			if (d == c) {
				count++;
			}
		}
		return count;
	}
}
