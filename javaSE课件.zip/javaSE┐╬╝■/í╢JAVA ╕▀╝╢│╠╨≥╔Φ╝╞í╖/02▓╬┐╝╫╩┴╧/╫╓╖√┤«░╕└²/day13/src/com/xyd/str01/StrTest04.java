/**
 * 
 */
package com.xyd.str01;

import java.io.UnsupportedEncodingException;

/**
 * @author scott
 * @date 2017年12月14日上午10:26:04
 * @version 
 * @description 
 */
public class StrTest04 {

	public static void main(String[] args) throws UnsupportedEncodingException {
		
		String str = "你好中国"; 
		
		//转成 byte[] 数组  
		byte[] bytes = null;
		try {
			bytes = str.getBytes("gbk");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		System.out.println(bytes.length);

		//中文乱码 
		// 1.编码不统一  
		byte[] date = str.getBytes("utf-8");
		
		//把 byte[] 转成对应的 (编码)字符串
		String string = new String(date,"utf-8");
		System.out.println(string);
		
		// 2.数据丢失
		String string2 = new String(date,0, date.length,"utf-8");
		System.out.println(string2);
		
	}
}
