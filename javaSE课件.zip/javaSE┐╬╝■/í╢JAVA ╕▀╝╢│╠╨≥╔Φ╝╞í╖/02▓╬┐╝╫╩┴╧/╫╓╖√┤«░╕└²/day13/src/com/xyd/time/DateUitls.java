/**
 * 
 */
package com.xyd.time;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author scott
 * @date 2017年12月14日下午3:40:38
 * @version 
 * @description 
 */
public class DateUitls {

	/**
	 * date to str
	 */
	public static String date2Str(Date date) {
		
		return new SimpleDateFormat("yyyy-MM-dd").format(date);
		
	}
	/**
	 * date to str
	 */
	public static String date2Str(Date date,String type) {
		
		return new SimpleDateFormat(type).format(date);
		
	}
	
	/**
	 * date to str
	 */
	public static String long2Str(long time) {
		
		return date2Str(new Date(time));
		
	}
}
