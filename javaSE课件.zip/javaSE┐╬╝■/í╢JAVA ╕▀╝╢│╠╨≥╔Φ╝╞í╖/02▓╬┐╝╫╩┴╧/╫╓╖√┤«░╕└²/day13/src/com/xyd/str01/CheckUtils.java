/**
 * 
 */
package com.xyd.str01;

/**
 * @author scott
 * @date 2017年12月14日下午2:10:17
 * @version 
 * @description 
 */
public class CheckUtils {

	public static boolean checkEmail(String str) {
		return str.matches("^[a-zA-Z0-9_-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+$");
	}
	
	/**
	 * 检查身份 证  是否 匹配
	 */
	public static boolean checkId(String id) {
		return id.matches("^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$");
	}
	
	/**
	 *  正则匹配  电话号码
	 */
	public static boolean checkPhone(String phone) {
		return phone.matches("^1[3|4|5|7|8][0-9]\\d{8}$");
	}
}

