/**
 * 
 */
package com.xyd.annotation;

/**
 * @author scott
 * @date 2017年12月27日下午3:23:54
 * @version 
 * @description 
 */
@MyAnnotation(info="happy new year")
public class AnnotationDemo {

	@MyAnnotation
	public void test01(String msg) {
		System.out.println("test01");
		System.out.println("hello " + msg);
	}
	
	@MyAnnotation(info = "元旦大家干啥...")
	public void test02(String msg) {
		System.out.println("test02");
		System.out.println("hello " + msg);
	}
	
}
