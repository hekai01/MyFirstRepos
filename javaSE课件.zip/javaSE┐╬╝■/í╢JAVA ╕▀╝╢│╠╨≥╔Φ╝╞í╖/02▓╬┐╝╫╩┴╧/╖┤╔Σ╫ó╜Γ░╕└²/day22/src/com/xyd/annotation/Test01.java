/**
 * 
 */
package com.xyd.annotation;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

/**
 * @author scott
 * @date 2017年12月27日下午2:45:07
 * @version 
 * @description 
 */
public class Test01 {

	public static void main(String[] args) {
		
		Date d = new Date();
		
		d.getDate();
		
		new Test01().test01();
	}
	
	@Deprecated // 标注内容，不再被建议使用
	public void test01() {
		
	}
	
//	@Override //只能标注   重写父类的方法 
//	public void test02() {
//		
//	}
	
	@Override
	public String toString() {
		return super.toString();
	}
	
	//@Retention   -- @Retention只能被用来标注“Annotation类型”，而且它被用来指定Annotation的RetentionPolicy属性。 
	//自定义注解   修饰 生命周期
    //@Target      -- @Target只能被用来标注“Annotation类型”，而且它被用来指定Annotation的ElementType属性。
	//自定义注解  修饰   注解的 使用范围
	
	//@SuppressWarnings -- @SuppressWarnings 所标注内容产生的警告，编译器会对这些警告保持静默。
	
	@SuppressWarnings(value = { "all" }) 
	public void test03() {
		String a = "aa";
		List list = new ArrayList();
		list.add(1);
		list.add(3);
		list.add(5);
	}
	
	static class Test{
		
	}
	
	class Test02{
		
	}
	
}
