/**
 * 
 */
package com.xyd.annotation;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author scott
 * @date 2017年12月27日下午3:28:21
 * @version 
 * @description  通过反射 拿到 自定义注解 内容
 */
public class TestAnnotation {

	public static void main(String[] args) throws Exception {
		
		//拿到Class 对象
		AnnotationDemo annotationDemo = new AnnotationDemo();
		
		Class<AnnotationDemo> clazz = (Class<AnnotationDemo>) annotationDemo.getClass();
		
//		testAnnation01(clazz);
		
		//通过反射 拿到 方法
		Method[] declaredMethods = clazz.getDeclaredMethods();
		
		for (Method method : declaredMethods) {
			
			//判断方法 有没有注解
			if (method.isAnnotationPresent(MyAnnotation.class)) {
				
				//拿到方法的注解  
				MyAnnotation annotation = method.getAnnotation(MyAnnotation.class);
				//拿到 注解的值
//				System.out.println(annotation.info());
				
				//通过反射 让方法 使用注解的值
				//test02(annotation.info())
				method.invoke(annotationDemo, annotation.info());
			}
		}
	}

	/*
	 * 拿到类的注解信息
	 */
	private static void testAnnation01(Class<AnnotationDemo> clazz) {
		//判断这个类 是否有注解
		boolean annotationPresent = clazz.isAnnotationPresent(MyAnnotation.class);
		if (annotationPresent) {
			MyAnnotation annotation = clazz.getAnnotation(MyAnnotation.class);
			System.out.println(annotation.info());
		}
	}
}
