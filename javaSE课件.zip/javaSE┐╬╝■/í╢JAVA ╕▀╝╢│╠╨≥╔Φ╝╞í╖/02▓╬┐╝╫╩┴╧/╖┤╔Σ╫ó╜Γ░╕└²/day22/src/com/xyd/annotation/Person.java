/**
 * 
 */
package com.xyd.annotation;

/**
 * @author scott
 * @date 2017年12月27日下午2:55:32
 * @version 
 * @description 
 */
public class Person {

	public void walk() {
		
	}

}
