/**
 * 
 */
package com.xyd.annotation;

/**
 * @author scott
 * @date 2017年12月27日下午2:55:20
 * @version 
 * @description  注解的  1 编译检查
 */
public class Test02 extends Person{

	@Override
	public void walk(){
	}
	
}
