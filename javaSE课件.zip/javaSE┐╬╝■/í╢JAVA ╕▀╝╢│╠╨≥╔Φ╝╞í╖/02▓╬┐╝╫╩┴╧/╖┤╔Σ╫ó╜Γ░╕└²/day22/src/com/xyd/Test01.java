/**
 * 
 */
package com.xyd;

/**
 * @author scott
 * @date 2017年12月29日下午4:14:23
 * @version 
 * @description 
 */
public class Test01 {

	public static void main(String[] args) {
	
		int a = 10;
		//打印   
		System.out.println(a);
		
	}
	
}
