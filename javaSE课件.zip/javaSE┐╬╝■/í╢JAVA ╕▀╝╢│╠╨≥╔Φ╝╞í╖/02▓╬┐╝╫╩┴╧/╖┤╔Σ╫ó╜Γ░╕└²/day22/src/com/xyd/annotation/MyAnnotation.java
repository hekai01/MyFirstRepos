/**
 * 
 */
package com.xyd.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author scott
 * @date 2017年12月27日下午3:13:11
 * @version 
 * @description 
 */

//@Target      -- @Target只能被用来标注“Annotation类型”，而且它被用来指定Annotation的ElementType属性。
//自定义注解  修饰   注解的 使用范围
//@Retention   -- @Retention只能被用来标注“Annotation类型”，而且它被用来指定Annotation的RetentionPolicy属性。 
//自定义注解   修饰 生命周期
//ElementType.METHOD    方法声明       TYPE,  /* 类、接口（包括注释类型）或枚举声明  */
@Target({ElementType.METHOD,ElementType.TYPE}) 
@Retention(RetentionPolicy.RUNTIME)    //注解的生命周期
public @interface MyAnnotation {

	String info() default "hello";
	
}
