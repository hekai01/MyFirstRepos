/**
 * 
 */
package com.xyd.info;

/**
 * @author scott
 * @date 2017年12月25日上午11:37:16
 * @version 
 * @description 
 */
public class TestStop {

	public static void main(String[] args) {

		StopThread stopThread = new StopThread();
		
		stopThread.start();
		
		for (int i = 0; i < 300; i++) {
			
			if (i == 100) {
				stopThread.stopThread();
			}
			System.out.println("main ... " + i);
		}
		
	}

}
