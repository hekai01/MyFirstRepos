/**
 * 
 */
package com.xyd.info;

/**
 * @author scott
 * @date 2017年12月25日上午11:13:22
 * @version 
 * @description 
 */
public class YieldThread extends Thread{

	@Override
	public void run() {

		for (int i = 0; i <300; i++) {
			
			System.out.println("我是 yield线程 ... " + i);
			
		}
	}
}
