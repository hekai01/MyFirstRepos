/**
 * 
 */
package com.xyd.info;

/**
 * @author scott
 * @date 2017年12月25日上午10:28:07
 * @version 
 * @description 线程   获取属性的方法: 
 */
public class TestMain {

	public static void main(String[] args) {
		
		//获取  当前的线程 方法    Thread.currentThread()
		Thread currentThread = Thread.currentThread();
		
		//线程获取属性的方法
		//获取线程的名字
		currentThread.setName("主线程");
		String name = currentThread.getName();
		System.out.println(name);

		//获取线程的id
		long id = currentThread.getId();
		System.out.println(id);
		
		//获取线程的优先级
		int priority = currentThread.getPriority();
		System.out.println(priority);
	}

}
