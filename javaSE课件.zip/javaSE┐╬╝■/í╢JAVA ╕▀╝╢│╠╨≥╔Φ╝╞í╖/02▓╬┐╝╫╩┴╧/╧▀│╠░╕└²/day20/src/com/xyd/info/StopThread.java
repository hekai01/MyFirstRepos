/**
 * 
 */
package com.xyd.info;

/**
 * @author scott
 * @date 2017年12月25日上午11:30:33
 * @version 
 * @description 
 */
public class StopThread extends Thread{
	
	private boolean flag = true;
	
	@Override
	public void run() {

		while (flag && !Thread.currentThread().isInterrupted()) {
			
			System.out.println("我在敲代码 ... ");
		}
	}

	public void stopThread() {
		this.flag = false;
		Thread.currentThread().interrupt();//同时中断线程，防止线程正在休眠中
		System.out.println("线程停止... ");
	}
	
}
