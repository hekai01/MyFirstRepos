/**
 * 
 */
package com.xyd.info;

/**
 * @author scott
 * @date 2017年12月25日上午10:38:06
 * @version 
 * @description 
 */
public class TestSleep {

	public static void main(String[] args) {

		SleepThread sleepThread = new SleepThread();
		
		sleepThread.start();
		
	}

}
