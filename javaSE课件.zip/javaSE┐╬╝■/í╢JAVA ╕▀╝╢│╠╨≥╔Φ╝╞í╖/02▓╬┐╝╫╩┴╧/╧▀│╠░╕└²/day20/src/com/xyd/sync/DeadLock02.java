/**
 * 
 */
package com.xyd.sync;

/**
 * @author scott
 * @date 2017年12月25日下午5:30:13
 * @version 
 * @description 
 */
public class DeadLock02 extends Thread{

	@Override
	public void run() {
		synchronized (TestDead.o2) {
			System.out.println("DeadLock02 is o2");
			
			synchronized (TestDead.o1) {
				System.out.println("DeadLock02 is o1");
			}
		}
	}
}
