/**
 * 
 */
package com.xyd.info;

/**
 * @author scott
 * @date 2017年12月25日上午11:24:09
 * @version 
 * @description  测试join 方法
 */
public class TestJoin {

	public static void main(String[] args) {

		JoinThread joinThread = new JoinThread();
		
		joinThread.start();
		
		for (int i = 0; i < 300; i++) {
			
			if (i == 200) {
				
				try {
				    System.out.println("线程"+Thread.currentThread().getName()+"等待");
				    //main 方法 等待   让  joinThread  先 执行  
					joinThread.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			System.out.println("main ..." + i);
		}
		
	}

}
