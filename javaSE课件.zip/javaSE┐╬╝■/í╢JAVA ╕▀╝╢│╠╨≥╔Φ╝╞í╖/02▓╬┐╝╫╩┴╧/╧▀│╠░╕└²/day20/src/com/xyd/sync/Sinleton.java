/**
 * 
 */
package com.xyd.sync;

/**
 * @author scott
 * @date 2017年12月25日下午3:35:18
 * @version
 * @description
 * 
 * 				懒汉 :线程 不安全 (多线程 单例 线程 不安全)
 * 
 *              1.私有构造 2.定义 静态变量 3.公开一个 static 方法 返回 一个 实例
 * 
 */
public class Sinleton {

	private Sinleton() {

	}

	private static Sinleton instance = null;

	public static Sinleton getInstance(long time) {
		
		//模拟 懒汉延时加载 
		// 100   a线程    单例  
		// 400   b线程
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		// 400   a线程    (不是) 单例  
		// 400   b线程
		if (instance == null) {
			instance = new Sinleton();
		}
		return instance;
	}

	//单例 的线程 安全   同步方法    
	// a  b  同步方法    只能一个现线程 进入
    public static synchronized Sinleton getInstance01(long time) {
		
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (instance == null) {
			instance = new Sinleton();
		}
		return instance;
	}
    
    //单例 的线程 安全   同步代码块    
    public static  Sinleton getInstance02(long time) {
    	
    	// a  b  同步方法    只能一个现线程 进入
    	synchronized (Sinleton.class) {
			try {
				Thread.sleep(time);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (instance == null) {
				instance = new Sinleton();
			}
			return instance;
		}
    }
    
    //单例 的线程 安全   同步代码块      提高效率 
    
    //单例 的线程 安全   同步代码块    
    public static  Sinleton getInstance03(long time) {
    	if (instance == null) {
    		//第一多线程 进来的时候  线程 安全  a , b 
    		synchronized (Sinleton.class) {
				//创建单例
				try {
					Thread.sleep(time);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				if (instance == null) {
					instance = new Sinleton();
				}
			}
		}
    	return instance;
    }
	
}
