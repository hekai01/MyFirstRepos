/**
 * 
 */
package com.xyd.info;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author scott
 * @date 2017年12月25日上午10:42:32
 * @version 
 * @description 
 *     思路:
 *       1.读取文本   用 io 操作
 *       
 *       2.操作字符串   charAt()
 *       
 *       3.sleep 下 
 * 
 */
public class ReadSong implements Runnable{

	@Override
	public void run() {
		
		String msg = readFile("src/song.txt");
		
		for (int i = 0; i < msg.length(); i++) {

			try {
				Thread.sleep(200L);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			char charAt = msg.charAt(i);
			System.out.print(charAt);
		}
	}

	/**
	 *  1.建立联系
	 *  2.选择流
	 *  3.操作
	 *  4.释放资源
	 */
	private String readFile(String string) {
		
		File file = new File(string);
		BufferedReader br = null;
		FileReader fr = null;
		try {
			fr = new FileReader(file);
			br = new BufferedReader(fr);
			
			char [] chs = new char[1024];
			int len = 0;
			
			StringBuilder sb = new StringBuilder();
			while ((len = br.read(chs)) != -1) {
				 String str = new String(chs, 0, len);
				 sb.append(str);
			}
			
			return sb.toString();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		
		return null;
	}

}
