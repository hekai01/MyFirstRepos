/**
 * 
 */
package com.xyd.create;

/**
 * @author scott
 * @date 2017年12月25日上午9:22:02
 * @version 
 * @description  正常的程序 都是一个个代码块  执行
 */
public class Demo01 {

	public static void main(String[] args) {
		
		for (int i = 0; i < 10; i++) {
			
			System.out.println("hello");
		}
		
		System.out.println("hello world");
		
		System.out.println("over ...");
	}
	
}
