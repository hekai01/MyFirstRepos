/**
 * 
 */
package com.xyd.sync;

/**
 * @author scott
 * @date 2017年12月25日下午3:40:15
 * @version 
 * @description 
 */
public class SingleThread extends Thread{

	private long time;
	
	public SingleThread(long time) {
		this.time = time;
	}

	@Override
	public void run() {
	
		System.out.println(Thread.currentThread().getId() + "----->" + Sinleton.getInstance02(time));
	}
}
