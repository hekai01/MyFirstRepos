/**
 * 
 */
package com.xyd.create;

/**
 * @author scott
 * @date 2017年12月25日上午9:35:37
 * @version 
 * @description  测试  线程创建方法 2: 通过 runnable 实现线程 
 */
public class TestThread02 {

	public static void main(String[] args) {
		
		//第一部    要 创建Runnable 实现类对象
		MyThread02 myThread02 = new MyThread02();
		//第二部    创建 系统线程类  new Thread(myThread02);
		Thread thread = new  Thread(myThread02);
		
		//启动线程
		thread.start();
		
		for (int i = 0; i < 20; i++) {
			
			System.out.println("main ... " + i);
			
		}
		
	}
}
