/**
 * 
 */
package com.xyd.create;

/**
 * @author scott
 * @date 2017年12月25日上午9:32:56
 * @version 
 * @description  线程创建的步骤:
 *                   1.要实现 线程接口: Runnable 
 *                   2.重写run方法 (线程中干活的方法)
 *                   3.线程启动 
 *                          1.要  创建runnable  实现类 myThread
 *                          2.要 创建系统的线程类 t = new Thread(myThread)
 *                          3.t.start() 调用start方法
 *                   
 */
public class MyThread02 implements Runnable{

	@Override
	public void run() {
		
		for (int i = 0; i < 20; i++) {
			System.out.println("我是子线程 ..." + i);
		}
	}

}
