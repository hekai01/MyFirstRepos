/**
 * 
 */
package com.xyd.sync;

/**
 * @author scott
 * @date 2017年12月25日下午3:39:02
 * @version 
 * @description 
 */
public class TestSingle {

	public static void main(String[] args) {
		
		//都在main线程中   不是多线程 
//		System.out.println(Sinleton.getInstance());
//		System.out.println(Sinleton.getInstance());
		
		//要线程 
		for (int i = 0; i < 5; i++) {
			test01();
		}
		
	}

	private static void test01() {
		SingleThread t1 = new SingleThread(400L);
		SingleThread t2 = new SingleThread(400L);
		
		t1.start();
		t2.start();
	}
}
