/**
 * 
 */
package com.xyd.sync;

/**
 * @author scott
 * @date 2017年12月25日下午5:28:18
 * @version 
 * @description 
 */
public class DeadLock01 extends Thread{

	@Override
	public void run() {
		
		synchronized (TestDead.o1) {
			
			System.out.println("DeadLock01 is o1" );
			
			synchronized (TestDead.o2) {
				System.out.println("DeadLock01 is o2" );
			}
			
		}
		
	}
}
