/**
 * 
 */
package com.xyd.create;

/**
 * @author scott
 * @date 2017年12月25日上午9:24:05
 * @version 
 * @description  线程的创建  :  
 *                   1. 线程类  继承   Thread(系统的线程类)
 *                   
 *                   2.重写run方法 (线程中 干活的方法)
 *                   
 *                   3.如何启动线程 : 创建自己定义的    线程类对象  调用start() 方法
 */
public class MyThread01 extends Thread{

	//干活的  方法
	@Override
	public void run() {
		
		for (int i = 0; i < 20; i++) {
			
			System.out.println("我是子线程 ..." + i);
		}
		
	}
	
}
