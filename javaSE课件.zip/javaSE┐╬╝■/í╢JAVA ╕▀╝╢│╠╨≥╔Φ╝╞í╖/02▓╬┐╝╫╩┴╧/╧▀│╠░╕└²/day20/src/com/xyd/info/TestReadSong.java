/**
 * 
 */
package com.xyd.info;

/**
 * @author scott
 * @date 2017年12月25日上午10:51:38
 * @version 
 * @description 
 */
public class TestReadSong {

	public static void main(String[] args) {
		
		// 创建接口的实现类
		ReadSong readSong = new ReadSong();
		
		//创建线程类
		Thread thread = new Thread(readSong);
		
		//启动 调用 start 方法
		thread.start();
	}
}
