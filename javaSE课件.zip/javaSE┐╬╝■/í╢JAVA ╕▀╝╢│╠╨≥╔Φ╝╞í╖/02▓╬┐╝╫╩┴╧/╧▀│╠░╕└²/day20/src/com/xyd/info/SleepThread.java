/**
 * 
 */
package com.xyd.info;

/**
 * @author scott
 * @date 2017年12月25日上午10:35:10
 * @version 
 * @description  创建Sleep线程类
 */
public class SleepThread extends Thread {

	@Override
	public void run() {
	
		for (int i = 10; i > 0; i--) {
			
			//睡眠   让cup 做其他的事情 
			try {
				Thread.sleep(1000L);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("倒计时 " + i);
		}
	}

}
