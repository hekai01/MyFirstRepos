/**
 * 
 */
package com.xyd.info;

/**
 * @author scott
 * @date 2017年12月25日上午11:14:20
 * @version 
 * @description 
 */
public class TestYield {
	
	public static void main(String[] args) {
		
		YieldThread yieldThread = new YieldThread();
		
		//启动线程
		yieldThread.start();
		
		for (int i = 0; i < 300; i++) {
			
			if (i == 150) {

				//main线程 让出cup
				Thread.currentThread().yield();
				
			}
			System.out.println("main... " + i);
			
		}
		
		
		
	}

}
