/**
 * 
 */
package com.xyd.sync;

/**
 * @author scott
 * @date 2017年12月25日下午5:28:48
 * @version 
 * @description 
 */
public class TestDead {

	public static Object o1 = new Object();
	public static Object o2 = new Object();
	
	public static void main(String[] args) {
		
		DeadLock01 deadLock01 = new DeadLock01();
		DeadLock02 deadLock02 = new DeadLock02();
		
		deadLock01.start();
		deadLock02.start();
		
	}
	
}
