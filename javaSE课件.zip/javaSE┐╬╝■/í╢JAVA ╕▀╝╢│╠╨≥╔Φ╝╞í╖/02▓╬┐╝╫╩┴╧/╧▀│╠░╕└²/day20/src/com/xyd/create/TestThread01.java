/**
 * 
 */
package com.xyd.create;

/**
 * @author scott
 * @date 2017年12月25日上午9:27:21
 * @version 
 * @description 测试  线程创建方法 1: 通过 继承Thread 实现线程 
 */
public class TestThread01 {

	public static void main(String[] args) {
		
		MyThread01 myThread = new MyThread01();
		myThread.start();
		
		for (int i = 0; i < 20; i++) {
			System.out.println("我是 main 线程 ..." + i);
		}
	}
}
