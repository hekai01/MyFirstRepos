/**
 * 
 */
package com.xyd.file;

import java.io.File;

/**
 * @author scott
 * @date 2017年12月21日下午2:52:05
 * @version 
 * @description  file 的一些方法   拿到属性
 */
public class Demo03 {

	public static void main(String[] args) {
		
		File file = new File("d:/a/a.txt");
		
		//文件名
		System.out.println(file.getName());
		
		//返回此File对象的绝对路径名
		System.out.println(file.getAbsolutePath());
		
		System.out.println(file.getPath());
		
		//判断的方法
		boolean isFile = file.isFile();
		
		//是否为  文件夹
		File file2 = new File("d:/a");
		System.out.println(file2.isDirectory() ? "是文件夹" : "不是文件夹");
		
		System.out.println(isFile ? "是文件" : "不是文件");
		
	}
}
