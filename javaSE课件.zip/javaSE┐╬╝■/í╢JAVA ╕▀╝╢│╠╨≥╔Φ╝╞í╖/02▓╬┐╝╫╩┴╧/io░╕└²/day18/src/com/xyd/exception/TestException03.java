/**
 * 
 */
package com.xyd.exception;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author scott
 * @date 2017年12月21日上午10:48:51
 * @version 
 * @description 
 *  再写一个方法void sanjiao(int a,int b,int c)，判断三个参数作为三角形的边事否能构成一个三角形， 
 *  如果不能则抛出异常 TrigonometricFunctionException ，
 *  显示异常信息"a,b,c不能构成三角 形"，如果可以构成则显示三角形三个边长，在main方法中得到命令行输入的三个整数，
 *  调用此方法，并捕获异常。
 */

public class TestException03 {

	public static void main(String[] args) {
	
		TestException03 test = new TestException03();
		
		try {
			test.sanjiao(5, 5, 11);
		} catch (TrigonometricFunctionException e) {
		
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}
	
	public void sanjiao(int a,int b,int c) throws TrigonometricFunctionException {
		
		if (!((a + b > c) && (a+c > b)&&(b + c >a))) {
			throw new TrigonometricFunctionException("a,b,c不能构成三 形");
		}
		
	}

	
	
}
