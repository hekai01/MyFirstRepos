/**
 * 
 */
package com.xyd.exception;

/**
 * @author scott
 * @date 2017年12月21日上午10:48:51
 * @version 
 * @description 编写程序，要求输入若干整数，输入的同时计算前面输入各数的乘积，若乘积超过100000，
 *                 则认为是异常，捕获并处理这个异常，输出信息。
 *                 
 *                思路
 *                  1: 若干整数  可变参数
 *                  2，若乘积超过100000，  判断 手动抛出异常 
 */

public class TestException01 {

	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		int c = 30;
		int d = 40;
		
		try {
			mul(a,b,c,d);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void mul(int ... arr) throws Exception {

		int mul = arr[0];
		
		for (int i = 1; i < arr.length; i++) {
			mul*=arr[i];
			if (mul > 100_000) {
				throw new Exception("若乘积超过100000, 则认为是异常，捕获并处理这个异常，输出信息");
			}
		}
	}
	
}
