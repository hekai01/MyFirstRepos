/**
 * 
 */
package com.xyd.exception;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author scott
 * @date 2017年12月21日上午10:48:51
 * @version 
 * @description 从控制台输入 5个整数，放入一整型数组，然后打印输出，
 *               要求：输入数据 为整数，要捕获Integer.parseInt()产生的异常，直至用户能够输入5个整数。（用户输入的不是整数则捕获异常）
 *               
 *               思路:
 *                1.创建数组 
 *                
 *                2.捕获异常
 *                
 *               
 */

public class TestException02 {

	public static void main(String[] args) {
	
		//键盘输入
		
		Scanner sc = new Scanner(System.in);
		
		int [] arr = new int[5];
		
		
		for (int i = 0; i < arr.length; i++) {
			
			System.out.println("请输入第"+(i +1)+"个数字");
			String next = sc.next();
			int num;
			try {
				num = Integer.parseInt(next);
				arr[i] = num;
			} catch (NumberFormatException e) {

				System.out.println("输入非法 请重新输入数字?");
				i --;
			}
			
		}
		
		System.out.println(Arrays.toString(arr));
	}

	
	
}
