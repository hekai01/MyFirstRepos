/**
 * 
 */
package com.xyd.exception;

/**
 * @author scott
 * @date 2017年12月21日上午11:00:54
 * @version 
 * @description  自定义异常步骤
 *             
 *              1.声明自定义类  继承   Exception
 *              
 *              2.重写 构造
 *              
 *              3.自己手动抛出
 * 
 */
public class TrigonometricFunctionException extends Exception {

	public TrigonometricFunctionException() {
		super();
	}

	public TrigonometricFunctionException(String message) {
		super(message);
	}

	
	
}
