/**
 * 
 */
package com.xyd.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author scott
 * @date 2017年12月21日下午4:55:16
 * @version 
 * @description 
 */
public class CopyImage {

	public static void main(String[] args) {
		
		//源 资源
		String srcPath = "D:\\javase\\day05\\视频\\for循环习题二.mp4";
		//赋值后的资源
		String destPath = "src/a.mp4";
		
		copyFile(srcPath,destPath);
	}

	private static void copyFile(String srcPath, String destPath) {
		
		File src = new File(srcPath);
		File dest = new File(destPath);
		
		copyFile(src,dest);
		
	}

	/*
	 * 1.建立联系
	 * 2.选择流 
	 * 3.操作
	 * 4.释放资源
	 */
	private static void copyFile(File src, File dest) {
		
		//选择流的操作
		
		FileInputStream fis = null;
		FileOutputStream fos = null;
		
		try {
			 fis = new FileInputStream(src);
			 fos = new FileOutputStream(dest);
			 
			 //操作
			 byte [] buffer = new byte[1024];
			 int len = 0;
			 //每次读取  buffer
			 while ((len = fis.read(buffer)) != -1) {
				 
				 System.out.println("len : "+buffer.length);
				 //每次把 buffer 都写出去
				 fos.write(buffer, 0, len);
			}
			fos.flush();
			
			System.out.println("复制成功");
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
//			if (fos != null) {
//				try {
//					fos.close();
//				} catch (IOException e) {
//					e.printStackTrace();
//				}
//			}
//			if (fis != null) {
//				try {
//					fos.close();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}
//			}
			
			IOUtils.close(fis,fos);
			
		}
		
	}
}
