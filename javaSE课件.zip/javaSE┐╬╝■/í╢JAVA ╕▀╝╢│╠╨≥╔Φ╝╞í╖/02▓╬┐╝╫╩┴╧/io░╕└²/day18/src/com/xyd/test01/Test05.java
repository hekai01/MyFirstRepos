/**
 * 
 */
package com.xyd.test01;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.w3c.dom.ls.LSInput;

/**
 * @author scott
 * @date 2017年12月21日上午9:47:23
 * @version 
 * @description 
 *      思路:
 *         1.一张牌  用对象来封装
 *         
 *         2.组装一副排
 *         
 *         3.洗牌
 *         
 *         
 */
public class Test05 {

	public static void main(String[] args) {
		
		String [] color = {"♠", "♥", "♣", "♦"};
		
		List<Poker> cards = new ArrayList<>();
		
		for (int i = 0; i < color.length; i++) {
			
			for (int j = 1; j <= 13; j++) {
				cards.add(new Poker(j, color[i]));
			}
			
		}
		cards.add(new Poker(50,"sKing"));
		cards.add(new Poker(100,"BKing"));
		
		//洗牌
		Collections.shuffle(cards);
		
		//发牌
		List<Poker> p1 = new ArrayList<>();
		List<Poker> p2 = new ArrayList<>();
		List<Poker> p3 = new ArrayList<>();
		List<Poker> last = new ArrayList<>();

		//发牌
		for (int i = 0; i < cards.size() - 3; i+=3) {
			
			p1.add(cards.get(i)); //0  3  6
			p2.add(cards.get(i+1));//1 4 
			p3.add(cards.get(i+2));//2 5 
			
		}
		
		//底牌
		last.add(cards.get(cards.size()-3));
		last.add(cards.get(cards.size()-2));
		last.add(cards.get(cards.size()-1));
		
		//整理排
		Collections.sort(p1);
		Collections.sort(p2);
		Collections.sort(p3);
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(last);
		
	}
	
}
