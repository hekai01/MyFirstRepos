/**
 * 
 */
package com.xyd.io;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

/**
 * @author scott
 * @date 2017年12月21日下午5:22:33
 * @version 
 * @description new BufferedInputStream(is) 构造器 
 * 
 * 
 */
public class BufferIoDemo01 {

	public static void main(String[] args) {
		
		String path = "src/a.txt";
		
		File file = new File(path);
		
		//选择流
		InputStream is = null;
		try {
			is = new BufferedInputStream(new FileInputStream(file));
			byte [] buffer = new byte[1024];
			//记录读取到那个位置了
			int len = 0;
			
			//如果不等于 - 1  我就继续读取  -1 就是 fis 的末端
			while ((len = is.read(buffer)) != -1) {
				
				//把 buffer 转成 字符串
				String str = new String(buffer, 0,len);
				System.out.println(str);
				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			IOUtils.close(is);
		}
	}
}
