/**
 * 
 */
package com.xyd.file;

import java.io.File;

/**
 * @author scott
 * @date 2017年12月21日下午3:24:45
 * @version
 * @description String[] list() 返回此目录中的文件名和目录名的数组
 * 
 *              File[] listFiles() 返回此目录中的文件和目录的File实例数组
 * 
 */
public class Demo05 {

	public static void main(String[] args) {

		File file = new File("E:/");

//		 test01(file);

		printFileName(file);

	}

	/**
	 * 使用File类浏览目录中的文件和子目录
	 */
	private static void test01(File file) {
		String[] list = file.list();

		for (String str : list) {
			// 文件名和目录名
			System.out.println(str);
		}

		System.out.println("**********************");
		File[] listFiles = file.listFiles();

		for (File file2 : listFiles) {
			System.out.println(file2.getName());
		}
	}

	/**
	 * 递归打印 文件中 所有的 文件的绝对路劲
	 */
	public static void printFileName(File src) {

		// 直接打印 这个文件的名字
		if (src.isFile()) {
			// 绝对路劲
			String absolutePath = src.getAbsolutePath();
			System.out.println(absolutePath);
		}
		if (src.isDirectory()) {

			File[] files = src.listFiles();

			for (File file : files) {
				printFileName(file);
			}
		}
	}

}
