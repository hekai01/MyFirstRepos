/**
 * 
 */
package com.xyd.io;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * @author scott
 * @date 2017年12月21日下午5:26:39
 * @version 
 * @description  用字节缓冲流 来复制  文本 
 */
public class Copy {

	public static void main(String[] args) {
		File src = new File("C:\\Users\\Administrator\\Desktop\\a.jpg");
		File dest = new File("src/a.jpg");
		
		copyFile(src, dest);
	}
	
	/**
	 * 1.建立联系
	 * 2.选择流  字节缓冲流
	 * 3.操作
	 * 4.释放资源
	 */
	public static void copyFile(File src,File dest) {
		BufferedInputStream bis =null;
		BufferedOutputStream bos = null;
		try {
			 bis = new BufferedInputStream(new FileInputStream(src));
			 bos = new BufferedOutputStream(new FileOutputStream(dest));
			 
			 
			 //操作
			 byte [] buffer = new byte[1024];
			 int len = 0;
			 while ((len = bis.read(buffer)) != - 1) {
				bos.write(buffer, 0, len);
				
			}
			 bos.flush();
			 
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			IOUtils.close(bis,bos);
		}
		
	}
	
}
