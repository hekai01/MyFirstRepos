/**
 * 
 */
package com.xyd.file;

import java.io.File;

/**
 * @author scott
 * @date 2017年12月22日上午9:01:56
 * @version
 * @description
 */
public class Demo06 {

	public static void main(String[] args) {
		File file = new File("D:/");
//		String[] list = file.list();
//		System.out.println(list);
//		for (String string : list) {
//			System.out.println(string);
//		}
//		File[] filelist = file.listFiles();
//		for (File file2 : filelist) {
//			System.out.println(file2.getName());
//		}
		System.out.println("*******");
		printFileName(file);

	}

	/**
	 * 
	 * @param src
	 *            递归打印所有路径
	 */

	public static void printFileName(File src) {
		
		if (src == null) {
			return;
		}
		
		if (src.isFile()) {
			System.out.println(src.getAbsolutePath());

		} else if (src.isDirectory()) {
			File[] files = src.listFiles();
			 if (files==null||files.length<=0)
			 return;
			for (File file : files) {
				printFileName(file);
			}
		}
	}

}
