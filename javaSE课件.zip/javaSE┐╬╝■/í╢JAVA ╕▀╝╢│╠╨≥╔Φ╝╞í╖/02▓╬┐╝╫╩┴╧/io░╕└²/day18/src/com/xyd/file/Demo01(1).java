/**
 * 
 */
package com.xyd.file;

import java.io.File;

/**
 * @author scott
 * @date 2017年12月21日下午2:40:08
 * @version 
 * @description File 类的常量   File.separator            分隔符
 *                          File.pathSeparator        路径分割符号
 */
public class Demo01 {

	public static void main(String[] args) {
		
		String path = "D:\\a.txt"; //windows 写法
		
		String path1 = "D:/a.txt"; //
		
		System.out.println("D:"+File.separator+"a.txt");
		
		System.out.println(path);
		
		System.out.println("D"+File.pathSeparator + File.separator + "a.txt");
	}
}
