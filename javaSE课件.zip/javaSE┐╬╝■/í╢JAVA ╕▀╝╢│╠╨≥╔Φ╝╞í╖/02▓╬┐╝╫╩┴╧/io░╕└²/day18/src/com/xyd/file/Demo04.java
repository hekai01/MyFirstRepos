/**
 * 
 */
package com.xyd.file;

import java.io.File;
import java.io.IOException;

/**
 * @author scott
 * @date 2017年12月21日下午2:59:22
 * @version 
 * @description 
 */
public class Demo04 {

	public static void main(String[] args) {
		
		//虚拟文件
		File file = new File("d:/a/b.txt");
		
		//如果你不是文件  
		if (!file.isFile()) {
			//创建文件
			try {
				boolean createNewFile = file.createNewFile();

				System.out.println(createNewFile ? "创建成功" : "创建失败");

			} catch (IOException e) {
				e.printStackTrace();
				System.out.println("创建失败");
			}
		}
		//删除文件
		boolean delete = file.delete();
		System.out.println(delete ? "删除成功" : "删除失败");

		//mkdir()    抽象路径名指定的目录  如果文件夹不存在  就会创建失败
//		File dir = new File("d:/b/b.txt");//创建失败
		File dir = new File("d:/a/b.txt");//创建成功
		
//		boolean k = dir.mkdir();
//		System.out.println(k ? "创建成功":"创建失败");
		
		//mkdirs()   抽象路径名指定的目录    如果文件夹不存在 一同创建
		File dir1 = new File("d:/b/b.txt");//创建成功
		boolean mkdirs = dir1.mkdirs();
		System.out.println(mkdirs ? "创建成功":"创建失败");
	}
}
