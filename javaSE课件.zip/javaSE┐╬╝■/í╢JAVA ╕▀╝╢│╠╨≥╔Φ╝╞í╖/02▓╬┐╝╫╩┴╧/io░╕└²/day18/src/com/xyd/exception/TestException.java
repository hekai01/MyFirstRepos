/**
 * 
 */
package com.xyd.exception;

/**
 * @author scott
 * @date 2017年12月21日上午10:23:07
 * @version
 * @description  代码执行 顺序:
 *               1.打印  代码执行的顺序
 *               
 *               2.debug 调试代码 查看代码是怎么走的
 *              
 */
public class TestException {

	void topGo() {

		try {

			middleGo();

		} catch (Exception e) {

			System.out.println("22");
			System.out.print("catch");

		}

	}

	void middleGo() throws Exception {

		go();
		System.out.println("32");
		System.out.print("late middle");

	}

	void go() throws Exception {

		throw new Exception();

	}
	
	public static void main(String[] args) {

		try {
			int parseInt = Integer.parseInt("agdafad");
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
