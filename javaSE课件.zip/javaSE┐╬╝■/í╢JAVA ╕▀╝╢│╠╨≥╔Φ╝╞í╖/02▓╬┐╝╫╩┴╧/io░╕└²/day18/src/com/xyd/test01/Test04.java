/**
 * 
 */
package com.xyd.test01;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author scott
 * @date 2017年12月21日上午9:33:30
 * @version 
 * @description  统计一个指定的字符串中每个字符出现的个数。把结果存入到一个Map中
 * 
 *           思路:
 *             1.用map<Character,Integer>记录 字符出现的次数
 *             
 *             2.判断  如果map.containsKey() , value + 1;
 *           
 * 
 */
public class Test04 {

	public static void main(String[] args) {
		
		String str = "heeewwwllojava";
		
		countCh(str);
		
	}

	private static void countCh(String str) {

		Map<Character, Integer> map = new HashMap<>();
		
		for (int i = 0; i < str.length(); i++) {
			
			//拿到每个字符串
			char charAt = str.charAt(i);
			//如果包含字符 +1
			if (map.containsKey(charAt)) {
				
				Integer count = map.get(charAt);
				count++;
				map.put(charAt, count);
				
			}else {
				//不包含 就直接给添加到  map中
				map.put(charAt, 1);
			}
		}

		Set<Entry<Character, Integer>> entrySet = map.entrySet();
		
		//获取迭代器
		Iterator<Entry<Character, Integer>> iterator = entrySet.iterator();
		
		//while 判断是否有下一个 (hasNext())
        while (iterator.hasNext()) {
			
        	Entry<Character, Integer> entry = iterator.next();
        	
        	System.out.println(entry.getKey()+"--->" +entry.getValue());
		}
		
	}
}
