/**
 * 
 */
package com.xyd.file;

import java.io.File;

/**
 * @author scott
 * @date 2017年12月21日下午2:47:04
 * @version 
 * @description  File  构造器 
 */
public class Demo02 {

	public static void main(String[] args) {
		
		//path
		File file = new File("d:/a/a.txt");
		System.out.println(file);

		//文件夹
		File parent = new File("d:/a");
		File file1 = new File(parent, "b.txt");
		System.out.println(file1);
		
		//
		File file2 = new File("d:/a", "c.txt");
		
		System.out.println(file2);
		
	}
}
