/**
 * 
 */
package com.xyd.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * @author scott
 * @date 2017年12月21日下午3:52:44
 * @version             二进制 
 * @description  文件中 ---------> 程序   输入流的操作 
 *                 
 *                 1.和文件建立  练习(把路劲转成 file)
 *                 
 *                 2.选择流(File输入流) new FileInputStream(file);  
 *                           
 *                 3.操作       把流中的 内容读取到  byte数组中
 *                 
 *                 4.释放资源(fis.close())
 *                 
 */
public class FileInpuStreamDemo01 {

	public static void main(String[] args) {
		
		//相对路径
		String path = "src/a.txt";
		
		// 1.和文件建立  练习(把路劲转成 file)
		File file = new File(path);
		FileInputStream fis = null;
		try {
			// 2. 选择流
//			FileInputStream fis = new FileInputStream("src/a.txt");
			fis = new FileInputStream(file);
			
			//操作  把 fis中的数据 读取到  byte 数组中
			// 1024b - > 1kb
			byte [] buffer = new byte[1024];
			//记录读取到那个位置了
			int len = 0;
			
			//如果不等于 - 1  我就继续读取  -1 就是 fis 的末端
			while ((len = fis.read(buffer)) != -1) {
				
				//把 buffer 转成 字符串
				String str = new String(buffer, 0,len);
				System.out.println(str);
				
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			//释放资源  
			if (fis != null) {
				try {
					fis.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
