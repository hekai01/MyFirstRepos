/**
 * 
 */
package com.xyd.mydecotor;

/**
 * @author scott
 * @date 2017年12月22日下午4:34:57
 * @version 
 * @description 
 */
public class WaterCar extends Car{

	@Override
	public void run() {

		System.out.println("汽车在 水里 游泳");
		
	}

}
