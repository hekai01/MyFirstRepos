/**
 * 
 */
package com.xyd.buffer;

import java.util.Scanner;

/**
 * @author scott
 * @date 2017年12月22日上午11:29:52
 * @version
 * @description
 */
public class Test01 {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		int a = 0;
		try {
			System.out.println("请输入非数字：");
			a = scan.nextInt();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		System.out.println(scan.hasNext());
		System.out.println("请输入：");
		String s = scan.next();
		System.out.println("a=" +a + "," +"s="+ s);

	}
}
