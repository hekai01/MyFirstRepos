/**
 * 
 */
package com.xyd.mydecotor;

/**
 * @author scott
 * @date 2017年12月22日下午4:32:08
 * @version 
 * @description 
 */
public abstract class Car {
	public abstract void run();
}
