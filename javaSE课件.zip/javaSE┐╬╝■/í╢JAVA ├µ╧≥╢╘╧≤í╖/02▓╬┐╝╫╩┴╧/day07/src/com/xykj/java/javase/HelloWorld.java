package com.xykj.java.javase;

public class HelloWorld {

}
