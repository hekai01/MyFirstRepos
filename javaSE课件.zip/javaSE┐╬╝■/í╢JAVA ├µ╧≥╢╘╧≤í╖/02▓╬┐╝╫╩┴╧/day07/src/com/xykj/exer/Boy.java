package com.xykj.exer;

public class Boy {
	private String name;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	
	public void setAge(int age) {
		this.age = age;
	}
	
	public void marry(Girl girl){
		System.out.println("��ҪȢ" + girl.getName());
	}
	
	public void marry(Boy boy){
		System.out.println("��ҪȢ" + boy.getName());
	}
	
	public void shout(){
		if(this.age >= 22){
			System.out.println("�ҵ��˽�������ˣ�");
		}else{
			System.out.println("������̸̸������");
		}
	}
}
