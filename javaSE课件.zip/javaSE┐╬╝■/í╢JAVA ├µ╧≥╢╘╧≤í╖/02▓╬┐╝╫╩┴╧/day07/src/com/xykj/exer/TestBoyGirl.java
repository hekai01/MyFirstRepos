package com.xykj.exer;

public class TestBoyGirl {
	public static void main(String[] args) {
		Boy boy = new Boy();
		boy.setName("������һ");
		boy.setAge(23);
		
		Girl girl = new Girl();
		girl.setName("С��");
		
		boy.marry(girl);
		boy.shout();
		System.out.println();
		girl.marry(boy);
		
		
	}
}
