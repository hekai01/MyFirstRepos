package com.xykj.exer;
import com.xykj.java.javase.*;
//import com.xykj.java.*;
public class TestHelloWorld {
	public static void main(String[] args) {
		HelloWorld w = new HelloWorld();
	}
}
