package com.xykj.java1;

public class Worker extends Person{
	public void eat(){
		System.out.println("���˳Է�");
	}
	 
	 public void walk(){
		 
	 }
}
