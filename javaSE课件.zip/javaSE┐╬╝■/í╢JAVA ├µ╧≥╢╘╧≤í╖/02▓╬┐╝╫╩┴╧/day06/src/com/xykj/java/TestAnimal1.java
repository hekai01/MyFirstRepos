package com.xykj.java;
import com.xykj.java1.Animal;

public class TestAnimal1 {
	public static void main(String[] args) {
		Animal a = new Animal();
		a.weight = 3.4;
		//a.eat();
	}
}
