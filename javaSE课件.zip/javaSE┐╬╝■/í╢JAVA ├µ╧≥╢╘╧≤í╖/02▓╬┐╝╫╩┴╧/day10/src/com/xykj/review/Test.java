package com.xykj.review;

import java.util.Date;

public class Test {
	public static void main(String[] args) {
		String str = new String("AA");
		System.out.println(str);
		
		Date d = new Date();
		System.out.println(d.toString());
		
		Integer i = new Integer(10);
		System.out.println(i.toString());
	}
}
