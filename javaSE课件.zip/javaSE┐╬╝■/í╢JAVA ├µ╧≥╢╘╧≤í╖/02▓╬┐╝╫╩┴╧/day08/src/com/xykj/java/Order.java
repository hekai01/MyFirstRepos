package com.xykj.java;

public class Order {
	private String orderName;
	int orderId;
	protected int orderNum;
	public String orderDesc;
	
	
	private void method1(){
		orderName = "AA";
	}
	void method2(){
		
	}
	protected void method3(){
		
	}
	public void method4(){
		
	}
}
