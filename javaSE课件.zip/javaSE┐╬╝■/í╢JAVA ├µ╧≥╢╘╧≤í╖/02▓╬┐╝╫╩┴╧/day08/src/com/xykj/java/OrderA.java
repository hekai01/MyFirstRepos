package com.xykj.java;

public class OrderA {
	public static void main(String[] args) {
		Order o = new Order();
//		o.orderName;
		o.orderDesc = null;
		o.orderId = 1;
		o.orderNum = 1001;
	}
}
