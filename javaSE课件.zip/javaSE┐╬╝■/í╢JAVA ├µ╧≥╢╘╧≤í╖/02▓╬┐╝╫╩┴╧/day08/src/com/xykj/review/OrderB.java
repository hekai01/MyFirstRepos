package com.xykj.review;

import com.xykj.java.Order;

public class OrderB {
	public static void main(String[] args) {
		Order o = new Order();
		o.orderDesc = null;
	}
}
class Order1 extends Order{
	public void method5(){
		orderNum = 1002;
		method3();
		//method2();
	}
}