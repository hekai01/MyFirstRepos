class TestIf4 
{
	public static void main(String[] args) 
	{
		int x = 4;
		int y = 1;
		if (x > 2) {
			 if (y > 2) 
                System.out.println(x + y);
             System.out.println("xykj");
		} else
       System.out.println("x is " + x);

	}
}
