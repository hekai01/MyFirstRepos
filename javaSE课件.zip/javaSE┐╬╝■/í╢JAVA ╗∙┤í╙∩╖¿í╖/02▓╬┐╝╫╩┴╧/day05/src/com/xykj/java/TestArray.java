package com.xykj.java;

public class TestArray {
	public static void main(String[] args) {
		int[] arr = new int[]{12,4,76,0,-98,-54,4,100};
		
		ArrayUtil au = new ArrayUtil();
		int max = au.getMax(arr);
		System.out.println("���ֵΪ��" + max);
		
		int avg = au.avg(arr);
		System.out.println("ƽ��ֵΪ��" + avg);
		
		au.printArray(arr);
		
		System.out.println("��ת���飺");
		au.reverse(arr);
		
		au.printArray(arr);
		
		System.out.println("����������");
		au.sort(arr,"asc");
		
		au.printArray(arr);
		
	}
}
