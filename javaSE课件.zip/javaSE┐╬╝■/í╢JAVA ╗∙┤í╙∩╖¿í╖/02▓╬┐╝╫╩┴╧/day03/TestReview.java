class TestReview 
{
	public static void main(String[] args) 
	{
		
		
		System.out.println(4>=3);
	}
}
