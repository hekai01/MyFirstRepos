package com.xykj;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午11:43:47
 */
@MapperScan(basePackages="com.xykj.mapper")
@SpringBootApplication
public class App {
	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
}
