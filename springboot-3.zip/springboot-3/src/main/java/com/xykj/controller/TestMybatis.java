package com.xykj.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.xykj.mapper.UserMapper;
import com.xykj.pojo.User;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午11:41:18
 */
@Controller
public class TestMybatis {
	@Autowired
	private UserMapper userMapper;
	
	@ResponseBody
	@RequestMapping("/getUserById/{id}")
	public User test1(@PathVariable("id") int id,Map<String,Object> map){
		User user = userMapper.getUserById(id);
		System.out.println("user:"+user);
		map.put("user", user);
		return user;
	}
}
