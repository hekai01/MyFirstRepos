package com.xykj.mapper;


import com.xykj.pojo.User;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月28日 上午11:36:32
 */
public interface UserMapper {
	
	//@Select("select * from users where id=#{id}")
	public User getUserById(int id);
	//@Insert("insert into users(name,age) values(#{name},#{age})")
	public int addUser(User user);
}
