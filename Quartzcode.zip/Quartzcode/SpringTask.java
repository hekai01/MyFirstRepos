package com.xykj.ssm.controller;

import java.util.Date;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月29日 上午10:20:05
 */
@Component
public class SpringTask {
	
	@Scheduled(cron="*/30 * * * * ?")
	public void doWork(){
		System.out.println("Spring自带的定时器...."+new Date());
	}
}
