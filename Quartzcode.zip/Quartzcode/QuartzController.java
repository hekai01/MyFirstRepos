package com.xykj.ssm.controller;

import java.util.Date;

/**
 * @TODO 
 * @author 林山
 * @Date 2018年9月29日 上午10:13:16
 */
public class QuartzController {
	
	public void test(){
		System.out.println("林工很帅。。。"+new Date());
	}
	
	public void test2(){
		System.out.println("每隔一分钟调用一次的触发器。。。"+new Date());
	}
}
